﻿Option Compare Binary
Option Explicit On
Option Strict On

Imports System.Windows.Forms

''' <summary>
''' 進捗状況を確認する画面です。
''' </summary>
''' <remarks></remarks>
Public Class StatusWindow

#Region " Fields "

    ''' <summary>
    ''' 移行元データベース接続情報
    ''' </summary>
    ''' <remarks></remarks>
    Private _srcDbInfo As SqlDatabase.SqlConnectionInfo

    ''' <summary>
    ''' 移行先データベース接続情報
    ''' </summary>
    ''' <remarks></remarks>
    Private _dstDbInfo As SqlDatabase.SqlConnectionInfo

#End Region

#Region " Public Property "

#Region " SourceDbConnectionInfo "

    ''' <summary>
    ''' 移行元データベース接続情報を取得または設定します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property SourceDbConnectionInfo() As SqlDatabase.SqlConnectionInfo
        Get
            Return _srcDbInfo
        End Get
        Set(ByVal value As SqlDatabase.SqlConnectionInfo)
            _srcDbInfo = value
        End Set
    End Property

#End Region

#Region " DestinationDbConnectionInfo "

    ''' <summary>
    ''' 移行先データベース接続情報を取得または設定します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DestinationDbConnectionInfo() As SqlDatabase.SqlConnectionInfo
        Get
            Return _dstDbInfo
        End Get
        Set(ByVal value As SqlDatabase.SqlConnectionInfo)
            _dstDbInfo = value
        End Set
    End Property

#End Region

#End Region

#Region " Event Procedure "

#Region " StatusWindow_Load "

    ''' <summary>
    ''' フォームロード時のイベントプロシージャです。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub StatusWindow_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.informationLabel.Text = "初期化処理中...."
        Me.Cursor = Cursors.WaitCursor

        BackgroundWorker1.RunWorkerAsync()
    End Sub

#End Region

#Region " BackgroundWorker1_DoWork "

    ''' <summary>
    ''' 非同期操作を開始します。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork

        Try
            '処理開始ログを出力
            LogManager.Append(LogManager.LogType.Information, Informations.ApplicationStart)

            Dim srcConnectionInfo As SqlDatabase.SqlConnectionInfo = _srcDbInfo
            Dim dstConnectionInfo As SqlDatabase.SqlConnectionInfo = _dstDbInfo

            Dim result As TransferManager.TranferResult
            Using manager As New TransferManager(srcConnectionInfo, dstConnectionInfo)
                result = manager.Execute(AddressOf ProcessReport)
                If result.IsSuccess Then
                    LogManager.Append(LogManager.LogType.Information, Informations.ApplicationComplete, New String() {result.SuccessObjectCount.ToString(), result.FailedObjectCount.ToString()})
                Else
                    LogManager.Append(LogManager.LogType.Critical, Informations.ApplicationFaield)
                End If

                manager.Close()
            End Using

            'ログファイルの出力
            LogManager.Write()

            Me.BackgroundWorker1.CancelAsync()

            '完了メッセージを表示
            If result.IsSuccess Then
                If result.FailedObjectCount = 0 Then
                    '失敗したオブジェクトが 1 件も無い場合は、正常終了メッセージを表示
                    MyBase.ShowInformationDialog(Informations.TransferFinished)
                Else
                    '失敗したオブジェクトが 1 件でも存在する場合は、警告メッセージを表示
                    MyBase.ShowExclamationDialog(Exclamations.PartFailed)
                End If
            Else
                MyBase.ShowErrorDialog(Errors.TransferFailed)
            End If
        Catch ex As Exception
            MyBase.ShowErrorDialog(ex)
        Finally
            Me.DialogResult = Windows.Forms.DialogResult.OK
        End Try

    End Sub

#End Region

#Region " BackgroundWorker1_ProgressChanged "

    ''' <summary>
    ''' 非同期操作の進行状況をユーザーに報告します。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub BackgroundWorker1_ProgressChanged(ByVal sender As System.Object, ByVal e As System.ComponentModel.ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
        Me.ProgressBar1.Value = e.ProgressPercentage
        Me.informationLabel.Text = e.UserState.ToString()
    End Sub

#End Region

#End Region

#Region " Private Method "

#Region " ProcessReport "

    ''' <summary>
    ''' ステータス変更イベントを発生させます。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub ProcessReport(ByVal sender As Object, ByVal e As TransferManager.ReportArgs)
        Me.BackgroundWorker1.ReportProgress(e.Percent, e.Message)
    End Sub

#End Region

#End Region

End Class