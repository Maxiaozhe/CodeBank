﻿Option Compare Binary
Option Explicit On
Option Strict On

Imports System
Imports System.Data
Imports System.Windows.Forms
Imports System.Drawing

''' <summary>
''' マイグレーションツールのメイン画面です。
''' </summary>
''' <remarks></remarks>
Public Class MainForm

#Region " Enum "

    ''' <summary>
    ''' 移行データベースの種別を表す列挙値を提供します。
    ''' </summary>
    ''' <remarks></remarks>
    Private Enum TransferDbType

        ''' <summary>
        ''' 移行元
        ''' </summary>
        ''' <remarks></remarks>
        Source

        ''' <summary>
        ''' 移行先
        ''' </summary>
        ''' <remarks></remarks>
        Destination

    End Enum

#End Region

#Region " Functions "

#Region " InitDisplay "

    ''' <summary>
    ''' 画面を初期化します。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitDisplay()

        Me.srcServerTextBox.Text = String.Empty
        Me.srcInstanceTextBox.Text = String.Empty
        Me.srcWinAuthRadioButton.Checked = True
        Me.srcLoginTextBox.Text = String.Empty
        Me.srcPasswordTextBox.Text = String.Empty
        Me.srcDatabaseComboBox.Items.Clear()

        Me.dstServerTextBox.Text = String.Empty
        Me.dstInstanceTextBox.Text = String.Empty
        Me.dstWinAuthRadioButton.Checked = True
        Me.dstLoginTextBox.Text = String.Empty
        Me.dstPasswordTextBox.Text = String.Empty
        Me.dstDatabaseComboBox.Items.Clear()

    End Sub

#End Region

#Region " GetConnectionInfo "

    ''' <summary>
    ''' データベースへの接続情報を取得します。
    ''' </summary>
    ''' <param name="dbType">移行データベースの種別</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetConnectionInfo(ByVal dbType As TransferDbType) As SqlDatabase.SqlConnectionInfo

        Dim connectionInfo As SqlDatabase.SqlConnectionInfo = Nothing
        Select Case dbType
            Case TransferDbType.Source : connectionInfo = GetConnectionInfo(dbType, Me.srcDatabaseComboBox.Text.Trim())
            Case TransferDbType.Destination : connectionInfo = GetConnectionInfo(dbType, Me.dstDatabaseComboBox.Text.Trim())
        End Select

        Return connectionInfo

    End Function

    ''' <summary>
    ''' データベースへの接続情報を取得します。
    ''' </summary>
    ''' <param name="dbType">移行データベースの種別</param>
    ''' <param name="database">接続先データベース名</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetConnectionInfo(ByVal dbType As TransferDbType, ByVal database As String) As SqlDatabase.SqlConnectionInfo

        Try
            Dim connectionInfo As SqlDatabase.SqlConnectionInfo = Nothing

            Select Case dbType
                Case TransferDbType.Source
                    If Me.srcWinAuthRadioButton.Checked Then
                        connectionInfo = New SqlDatabase.SqlConnectionInfo(Me.srcServerTextBox.Text.Trim(), database)
                    Else
                        connectionInfo = New SqlDatabase.SqlConnectionInfo(Me.srcServerTextBox.Text.Trim(), _
                                                                            Me.srcLoginTextBox.Text.Trim(), _
                                                                            Me.srcPasswordTextBox.Text, _
                                                                            database)
                    End If

                    If Not Me.srcInstanceTextBox.Text.Trim().Equals(String.Empty) Then connectionInfo.Instance = Me.srcInstanceTextBox.Text.Trim()
                Case TransferDbType.Destination
                    If Me.dstWinAuthRadioButton.Checked Then
                        connectionInfo = New SqlDatabase.SqlConnectionInfo(Me.dstServerTextBox.Text.Trim(), database)
                    Else
                        connectionInfo = New SqlDatabase.SqlConnectionInfo(Me.dstServerTextBox.Text.Trim(), _
                                                                            Me.dstLoginTextBox.Text.Trim(), _
                                                                            Me.dstPasswordTextBox.Text, _
                                                                            database)
                    End If

                    If Not Me.dstInstanceTextBox.Text.Trim().Equals(String.Empty) Then connectionInfo.Instance = Me.dstInstanceTextBox.Text.Trim()
            End Select

            Return connectionInfo
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " Connectable "

    ''' <summary>
    ''' データベースに接続可能かどうかを取得します。
    ''' </summary>
    ''' <param name="dbType">移行データベースの種別</param>
    ''' <returns>接続準備ができていない場合は False を返します。</returns>
    ''' <remarks></remarks>
    Private Function Connectable(ByVal dbType As TransferDbType) As Boolean
        Return Connectable(dbType, True)
    End Function

    ''' <summary>
    ''' データベースに接続可能かどうかを取得します。
    ''' </summary>
    ''' <param name="dbType">移行データベースの種別</param>
    ''' <param name="referDatabase">データベースも参照するかどうか</param>
    ''' <returns>接続準備ができていない場合は False を返します。</returns>
    ''' <remarks></remarks>
    Private Function Connectable(ByVal dbType As TransferDbType, ByVal referDatabase As Boolean) As Boolean

        Try
            'チェック用コントロール
            Dim serverTextBox As TextBox = Nothing
            Dim sqlAuthRadioButton As RadioButton = Nothing
            Dim loginTextBox As TextBox = Nothing
            Dim databaseComboBox As ComboBox = Nothing

            Select Case dbType
                Case TransferDbType.Source
                    serverTextBox = Me.srcServerTextBox
                    sqlAuthRadioButton = Me.srcSqlAuthRadioButton
                    loginTextBox = Me.srcLoginTextBox
                    databaseComboBox = Me.srcDatabaseComboBox
                Case TransferDbType.Destination
                    serverTextBox = Me.dstServerTextBox
                    sqlAuthRadioButton = Me.dstSqlAuthRadioButton
                    loginTextBox = Me.dstLoginTextBox
                    databaseComboBox = Me.dstDatabaseComboBox
            End Select

            'サーバーが未入力
            If serverTextBox.Text.Trim().Equals(String.Empty) Then
                MyBase.ShowExclamationDialog(Exclamations.ServerNotEntry)
                serverTextBox.Focus()
                Return False
            End If
            'SQL Server 認証の場合に、ログインが未入力
            If sqlAuthRadioButton.Checked AndAlso loginTextBox.Text.Trim().Equals(String.Empty) Then
                MyBase.ShowExclamationDialog(Exclamations.LoginNotEntry)
                loginTextBox.Focus()
                Return False
            End If
            'データベースの入力も確認する場合に、データベースが未入力
            If referDatabase AndAlso databaseComboBox.Text.Trim().Equals(String.Empty) Then
                MyBase.ShowExclamationDialog(Exclamations.DatabaseNotEntry)
                databaseComboBox.Focus()
                Return False
            End If
        Catch ex As Exception
            Throw
        End Try

        Return True

    End Function

#End Region

#Region " ChangeButtonEnabled "

    ''' <summary>
    ''' フォーム上のすべてのボタンの Enabled プロパティを変更します。
    ''' </summary>
    ''' <param name="enabled"></param>
    ''' <remarks></remarks>
    Private Sub ChangeButtonEnabled(ByVal enabled As Boolean)

        Me.OKButton.Enabled = enabled
        Me.CloseButton.Enabled = enabled
        Me.srcRenewButton.Enabled = enabled
        Me.srcDbConnectTestButton.Enabled = enabled
        Me.dstRenewButton.Enabled = enabled
        Me.dstDbConnectTestButton.Enabled = enabled

    End Sub

#End Region

#End Region

#Region " Events "

#Region " MainForm_Load "

    ''' <summary>
    ''' フォームロード時のイベントプロシージャです。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try
            '画面の初期化
            InitDisplay()

#If DEBUG Then
            Me.srcServerTextBox.Text = "(local)"
            Me.srcDatabaseComboBox.Text = "RabitFlow_SRC"
            Me.dstServerTextBox.Text = "(local)"
            Me.dstDatabaseComboBox.Text = "RabitFlow"
#End If
        Catch ex As Exception
            MyBase.ShowErrorDialog(ex)
        End Try

    End Sub

#End Region

#Region " CloseButton_Click "

    ''' <summary>
    ''' キャンセルボタンクリック時のイベントプロシージャです。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub CloseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseButton.Click
        Me.Close()
    End Sub

#End Region

#Region " AuthRadioButton_CheckedChanged "

    ''' <summary>
    ''' 認証ラジオボタン選択時のイベントプロシージャです。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub AuthRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) _
        Handles srcWinAuthRadioButton.CheckedChanged, srcSqlAuthRadioButton.CheckedChanged, dstWinAuthRadioButton.CheckedChanged, dstSqlAuthRadioButton.CheckedChanged

        Try
            Dim rb As RadioButton = TryCast(sender, RadioButton)
            If rb Is Nothing Then Return

            Dim enabled As Boolean
            Select Case rb.Name
                Case Me.srcWinAuthRadioButton.Name, Me.dstWinAuthRadioButton.Name : enabled = Not rb.Checked
                Case Me.srcSqlAuthRadioButton.Name, Me.dstSqlAuthRadioButton.Name : enabled = rb.Checked
            End Select

            Select Case rb.Name
                Case Me.srcWinAuthRadioButton.Name, Me.srcSqlAuthRadioButton.Name
                    Me.srcLoginTextBox.Enabled = enabled
                    Me.srcPasswordTextBox.Enabled = enabled
                Case Me.dstWinAuthRadioButton.Name, Me.dstSqlAuthRadioButton.Name
                    Me.dstLoginTextBox.Enabled = enabled
                    Me.dstPasswordTextBox.Enabled = enabled
            End Select
        Catch ex As Exception
            MyBase.ShowErrorDialog(ex)
        End Try

    End Sub

#End Region

#Region " DbConnectTestButton_Click "

    ''' <summary>
    ''' 接続のテストボタンクリック時のイベントプロシージャです。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub DbConnectTestButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles srcDbConnectTestButton.Click, dstDbConnectTestButton.Click

        Try
            Dim b As Button = TryCast(sender, Button)
            If b Is Nothing Then Return

            Dim connectionInfo As SqlDatabase.SqlConnectionInfo = Nothing
            Select Case b.Name
                Case srcDbConnectTestButton.Name
                    If Not Connectable(TransferDbType.Source) Then Return
                    connectionInfo = GetConnectionInfo(TransferDbType.Source)
                Case dstDbConnectTestButton.Name
                    If Not Connectable(TransferDbType.Destination) Then Return
                    connectionInfo = GetConnectionInfo(TransferDbType.Destination)
            End Select

            Dim exp As Exception = Nothing
            If SqlDatabase.TryConnect(connectionInfo, exp) Then
                MyBase.ShowInformationDialog(Informations.ConnectionSuccess)
            Else
                Throw exp
            End If
        Catch ex As Exception
            MyBase.ShowErrorDialog(ex)
        End Try

    End Sub

#End Region

#Region " RenewButton_Click "

    ''' <summary>
    ''' データベースコンボボックスクリック時のイベントプロシージャです。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub RenewButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles srcRenewButton.Click, dstRenewButton.Click

        Try
            Dim b As Button = TryCast(sender, Button)
            If b Is Nothing Then Return

            Const connectDatabase As String = "master"
            Dim connectionInfo As SqlDatabase.SqlConnectionInfo = Nothing
            Dim targetComboBox As ComboBox = Nothing
            Select Case b.Name
                Case Me.srcRenewButton.Name
                    If Not Connectable(TransferDbType.Source, False) Then Return
                    connectionInfo = GetConnectionInfo(TransferDbType.Source, connectDatabase)
                    targetComboBox = Me.srcDatabaseComboBox
                Case Me.dstRenewButton.Name
                    If Not Connectable(TransferDbType.Destination, False) Then Return
                    connectionInfo = GetConnectionInfo(TransferDbType.Destination, connectDatabase)
                    targetComboBox = Me.dstDatabaseComboBox
            End Select

            Using db As New SqlDatabase(connectionInfo)
                db.Open()

                targetComboBox.Items.Clear()
                For Each database As String In db.Executor.SelectDatabases()
                    targetComboBox.Items.Add(database)
                Next

                db.Close()
            End Using

        Catch ex As Exception
            MyBase.ShowErrorDialog(ex)
        End Try

    End Sub

#End Region

#Region " TextBox_Enter "

    ''' <summary>
    ''' 各種テキストボックスがフォーカスを取得したときのイベントプロシージャです。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub TextBox_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
        srcServerTextBox.Enter, srcInstanceTextBox.Enter, srcLoginTextBox.Enter, srcPasswordTextBox.Enter, _
        dstServerTextBox.Enter, dstInstanceTextBox.Enter, dstLoginTextBox.Enter, dstPasswordTextBox.Enter

        Try
            Dim tb As TextBox = TryCast(sender, TextBox)
            If tb Is Nothing Then Return

            tb.BackColor = Color.Pink
            tb.SelectAll()
        Catch ex As Exception
            '何もしない
        End Try

    End Sub

#End Region

#Region " ComboBox_Enter "

    ''' <summary>
    ''' 各種コンボボックスがフォーカスを取得したときのイベントプロシージャです。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub ComboBox_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles srcDatabaseComboBox.Enter, dstDatabaseComboBox.Enter

        Try
            Dim cb As ComboBox = TryCast(sender, ComboBox)
            If cb Is Nothing Then Return

            cb.BackColor = Color.Pink
            cb.SelectAll()
        Catch ex As Exception
            '何もしない
        End Try

    End Sub

#End Region

#Region " TextBox_Enter "

    ''' <summary>
    ''' 各種テキストボックスがフォーカスを取得したときのイベントプロシージャです。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub TextBox_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _
        srcServerTextBox.Leave, srcInstanceTextBox.Leave, srcLoginTextBox.Leave, srcPasswordTextBox.Leave, _
        dstServerTextBox.Leave, dstInstanceTextBox.Leave, dstLoginTextBox.Leave, dstPasswordTextBox.Leave

        Try
            Dim tb As TextBox = TryCast(sender, TextBox)
            If tb Is Nothing Then Return

            tb.BackColor = SystemColors.Window
        Catch ex As Exception
            '何もしない
        End Try

    End Sub

#End Region

#Region " ComboBox_Leave "

    ''' <summary>
    ''' 各種コンボボックスがフォーカスを喪失したときのイベントプロシージャです。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub ComboBox_Leave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles srcDatabaseComboBox.Leave, dstDatabaseComboBox.Leave

        Try
            Dim cb As ComboBox = TryCast(sender, ComboBox)
            If cb Is Nothing Then Return

            cb.BackColor = SystemColors.Window
        Catch ex As Exception
            '何もしない
        End Try

    End Sub

#End Region

#Region " OKButton_Click "

    ''' <summary>
    ''' OK ボタンクリック時のイベントプロシージャです。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click

        Try
            '入力チェック
            If Not Connectable(TransferDbType.Source) Then Return
            If Not Connectable(TransferDbType.Destination) Then Return

            '確認メッセージ
            If MyBase.ShowQuestionDialog(Questions.BeginTransfer, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.No Then Return

            Using dlg As New StatusWindow()
                dlg.SourceDbConnectionInfo = GetConnectionInfo(TransferDbType.Source)
                dlg.DestinationDbConnectionInfo = GetConnectionInfo(TransferDbType.Destination)

                dlg.ShowDialog(Me)
            End Using

            ChangeButtonEnabled(False)
        Catch ex As Exception
            MyBase.ShowErrorDialog(ex)
        Finally
            ChangeButtonEnabled(True)
        End Try

    End Sub

#End Region

#End Region

End Class
