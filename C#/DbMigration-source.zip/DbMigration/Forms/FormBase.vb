﻿Option Compare Binary
Option Explicit On
Option Strict On

Imports System.Windows.Forms

Public Class FormBase

#Region " Protected Method "

#Region " ShowErrorDialog "

    ''' <summary>
    ''' 例外の内容をダイアログ表示します。
    ''' </summary>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Protected Overloads Sub ShowErrorDialog(ByVal e As Exception)

        Dim formatArgs As String() = New String() {e.Message, ControlChars.CrLf, e.StackTrace}
        Dim message As String = String.Format("{0}{1}{1}{2}", formatArgs)

        MessageBox.Show(message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)

    End Sub

    ''' <summary>
    ''' エラーダイアログを表示します。
    ''' </summary>
    ''' <param name="messageType"></param>
    ''' <param name="formatArgs"></param>
    ''' <remarks></remarks>
    Protected Overloads Sub ShowErrorDialog(ByVal messageType As Errors, ByVal ParamArray formatArgs As String())
        Dim message As String = My.Resources.Errors.ResourceManager.GetString(messageType.ToString())
        If formatArgs IsNot Nothing AndAlso formatArgs.Length <> 0 Then message = String.Format(message, formatArgs)
        MessageBox.Show(message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
    End Sub

#End Region

#Region " ShowInformationDialog "

    ''' <summary>
    ''' インフォーメーションダイアログを表示します。
    ''' </summary>
    ''' <param name="messageType">ダイアログに表示するメッセージの種別</param>
    ''' <param name="formatArgs">フォーマット引数</param>
    ''' <remarks></remarks>
    Protected Sub ShowInformationDialog(ByVal messageType As Informations, ByVal ParamArray formatArgs As String())
        Dim message As String = My.Resources.Informations.ResourceManager.GetString(messageType.ToString())
        If formatArgs IsNot Nothing AndAlso formatArgs.Length <> 0 Then message = String.Format(message, formatArgs)
        MessageBox.Show(message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

#End Region

#Region " ShowExclamationDialog "

    ''' <summary>
    ''' 警告ダイアログを表示します。
    ''' </summary>
    ''' <param name="messageType">ダイアログに表示するメッセージの種別</param>
    ''' <param name="formatArgs">フォーマット引数</param>
    ''' <remarks></remarks>
    Protected Sub ShowExclamationDialog(ByVal messageType As Exclamations, ByVal ParamArray formatArgs As String())
        Dim message As String = My.Resources.Exclamations.ResourceManager.GetString(messageType.ToString())
        If formatArgs IsNot Nothing AndAlso formatArgs.Length <> 0 Then message = String.Format(message, formatArgs)
        MessageBox.Show(message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub

#End Region

#Region " ShowQuestionDialog "

    ''' <summary>
    ''' 確認ダイアログを表示します。
    ''' </summary>
    ''' <param name="messageType">ダイアログに表示するメッセージの種別</param>
    ''' <param name="formatArgs">フォーマット引数</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Overloads Function ShowQuestionDialog(ByVal messageType As Questions, ByVal ParamArray formatArgs As String()) As DialogResult
        Return ShowQuestionDialog(messageType, MessageBoxDefaultButton.Button1, formatArgs)
    End Function

    ''' <summary>
    ''' 確認ダイアログを表示します。
    ''' </summary>
    ''' <param name="messageType">ダイアログに表示するメッセージの種別</param>
    ''' <param name="defaultButton">デフォルトで選択するボタン</param>
    ''' <param name="formatArgs">フォーマット引数</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Overloads Function ShowQuestionDialog(ByVal messageType As Questions, ByVal defaultButton As MessageBoxDefaultButton, ByVal ParamArray formatArgs As String()) As DialogResult
        Dim message As String = My.Resources.Questions.ResourceManager.GetString(messageType.ToString())
        If formatArgs IsNot Nothing AndAlso formatArgs.Length <> 0 Then message = String.Format(message, formatArgs)
        Return MessageBox.Show(message, Application.ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question, defaultButton)
    End Function

#End Region

#End Region

End Class