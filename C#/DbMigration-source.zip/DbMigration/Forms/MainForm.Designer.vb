﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits FormBase

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.srcRenewButton = New System.Windows.Forms.Button
        Me.srcDbConnectTestButton = New System.Windows.Forms.Button
        Me.srcInstanceTextBox = New System.Windows.Forms.TextBox
        Me.srcServerTextBox = New System.Windows.Forms.TextBox
        Me.srcDatabaseComboBox = New System.Windows.Forms.ComboBox
        Me.srcPasswordTextBox = New System.Windows.Forms.TextBox
        Me.srcLoginTextBox = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.srcSqlAuthRadioButton = New System.Windows.Forms.RadioButton
        Me.srcWinAuthRadioButton = New System.Windows.Forms.RadioButton
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.CloseButton = New System.Windows.Forms.Button
        Me.OKButton = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.dstRenewButton = New System.Windows.Forms.Button
        Me.dstDbConnectTestButton = New System.Windows.Forms.Button
        Me.dstInstanceTextBox = New System.Windows.Forms.TextBox
        Me.dstServerTextBox = New System.Windows.Forms.TextBox
        Me.dstDatabaseComboBox = New System.Windows.Forms.ComboBox
        Me.dstPasswordTextBox = New System.Windows.Forms.TextBox
        Me.dstLoginTextBox = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.dstSqlAuthRadioButton = New System.Windows.Forms.RadioButton
        Me.dstWinAuthRadioButton = New System.Windows.Forms.RadioButton
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.srcRenewButton)
        Me.GroupBox1.Controls.Add(Me.srcDbConnectTestButton)
        Me.GroupBox1.Controls.Add(Me.srcInstanceTextBox)
        Me.GroupBox1.Controls.Add(Me.srcServerTextBox)
        Me.GroupBox1.Controls.Add(Me.srcDatabaseComboBox)
        Me.GroupBox1.Controls.Add(Me.srcPasswordTextBox)
        Me.GroupBox1.Controls.Add(Me.srcLoginTextBox)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.srcSqlAuthRadioButton)
        Me.GroupBox1.Controls.Add(Me.srcWinAuthRadioButton)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(609, 186)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "移行元データベース"
        '
        'srcRenewButton
        '
        Me.srcRenewButton.Location = New System.Drawing.Point(297, 154)
        Me.srcRenewButton.Name = "srcRenewButton"
        Me.srcRenewButton.Size = New System.Drawing.Size(108, 23)
        Me.srcRenewButton.TabIndex = 8
        Me.srcRenewButton.Text = "最新の情報に更新"
        Me.srcRenewButton.UseVisualStyleBackColor = True
        '
        'srcDbConnectTestButton
        '
        Me.srcDbConnectTestButton.Location = New System.Drawing.Point(524, 154)
        Me.srcDbConnectTestButton.Name = "srcDbConnectTestButton"
        Me.srcDbConnectTestButton.Size = New System.Drawing.Size(79, 23)
        Me.srcDbConnectTestButton.TabIndex = 9
        Me.srcDbConnectTestButton.Text = "接続のテスト"
        Me.srcDbConnectTestButton.UseVisualStyleBackColor = True
        '
        'srcInstanceTextBox
        '
        Me.srcInstanceTextBox.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.srcInstanceTextBox.Location = New System.Drawing.Point(91, 39)
        Me.srcInstanceTextBox.MaxLength = 64
        Me.srcInstanceTextBox.Name = "srcInstanceTextBox"
        Me.srcInstanceTextBox.Size = New System.Drawing.Size(200, 19)
        Me.srcInstanceTextBox.TabIndex = 2
        '
        'srcServerTextBox
        '
        Me.srcServerTextBox.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.srcServerTextBox.Location = New System.Drawing.Point(91, 19)
        Me.srcServerTextBox.MaxLength = 64
        Me.srcServerTextBox.Name = "srcServerTextBox"
        Me.srcServerTextBox.Size = New System.Drawing.Size(200, 19)
        Me.srcServerTextBox.TabIndex = 1
        '
        'srcDatabaseComboBox
        '
        Me.srcDatabaseComboBox.FormattingEnabled = True
        Me.srcDatabaseComboBox.Location = New System.Drawing.Point(91, 157)
        Me.srcDatabaseComboBox.Name = "srcDatabaseComboBox"
        Me.srcDatabaseComboBox.Size = New System.Drawing.Size(200, 20)
        Me.srcDatabaseComboBox.TabIndex = 7
        '
        'srcPasswordTextBox
        '
        Me.srcPasswordTextBox.Location = New System.Drawing.Point(176, 133)
        Me.srcPasswordTextBox.Name = "srcPasswordTextBox"
        Me.srcPasswordTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.srcPasswordTextBox.Size = New System.Drawing.Size(229, 19)
        Me.srcPasswordTextBox.TabIndex = 6
        '
        'srcLoginTextBox
        '
        Me.srcLoginTextBox.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.srcLoginTextBox.Location = New System.Drawing.Point(176, 113)
        Me.srcLoginTextBox.MaxLength = 64
        Me.srcLoginTextBox.Name = "srcLoginTextBox"
        Me.srcLoginTextBox.Size = New System.Drawing.Size(229, 19)
        Me.srcLoginTextBox.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(108, 133)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(79, 21)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "パスワード"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(108, 112)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(79, 21)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "ログイン"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'srcSqlAuthRadioButton
        '
        Me.srcSqlAuthRadioButton.Location = New System.Drawing.Point(92, 88)
        Me.srcSqlAuthRadioButton.Name = "srcSqlAuthRadioButton"
        Me.srcSqlAuthRadioButton.Size = New System.Drawing.Size(167, 21)
        Me.srcSqlAuthRadioButton.TabIndex = 4
        Me.srcSqlAuthRadioButton.TabStop = True
        Me.srcSqlAuthRadioButton.Text = "SQL Server 認証"
        Me.srcSqlAuthRadioButton.UseVisualStyleBackColor = True
        '
        'srcWinAuthRadioButton
        '
        Me.srcWinAuthRadioButton.Location = New System.Drawing.Point(92, 64)
        Me.srcWinAuthRadioButton.Name = "srcWinAuthRadioButton"
        Me.srcWinAuthRadioButton.Size = New System.Drawing.Size(167, 21)
        Me.srcWinAuthRadioButton.TabIndex = 3
        Me.srcWinAuthRadioButton.TabStop = True
        Me.srcWinAuthRadioButton.Text = "Windows 認証"
        Me.srcWinAuthRadioButton.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(6, 158)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(79, 21)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "データベース"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(6, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 21)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "インスタンス名"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(6, 60)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(79, 21)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "認証"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(6, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(79, 21)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "サーバー"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'CloseButton
        '
        Me.CloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.CloseButton.Location = New System.Drawing.Point(542, 395)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(79, 23)
        Me.CloseButton.TabIndex = 9
        Me.CloseButton.Text = "Cancel"
        Me.CloseButton.UseVisualStyleBackColor = True
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(457, 395)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.Size = New System.Drawing.Size(79, 23)
        Me.OKButton.TabIndex = 10
        Me.OKButton.Text = "OK"
        Me.OKButton.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.dstRenewButton)
        Me.GroupBox2.Controls.Add(Me.dstDbConnectTestButton)
        Me.GroupBox2.Controls.Add(Me.dstInstanceTextBox)
        Me.GroupBox2.Controls.Add(Me.dstServerTextBox)
        Me.GroupBox2.Controls.Add(Me.dstDatabaseComboBox)
        Me.GroupBox2.Controls.Add(Me.dstPasswordTextBox)
        Me.GroupBox2.Controls.Add(Me.dstLoginTextBox)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.dstSqlAuthRadioButton)
        Me.GroupBox2.Controls.Add(Me.dstWinAuthRadioButton)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 204)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(609, 186)
        Me.GroupBox2.TabIndex = 9
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "移行先データベース"
        '
        'dstRenewButton
        '
        Me.dstRenewButton.Location = New System.Drawing.Point(297, 154)
        Me.dstRenewButton.Name = "dstRenewButton"
        Me.dstRenewButton.Size = New System.Drawing.Size(108, 23)
        Me.dstRenewButton.TabIndex = 8
        Me.dstRenewButton.Text = "最新の情報に更新"
        Me.dstRenewButton.UseVisualStyleBackColor = True
        '
        'dstDbConnectTestButton
        '
        Me.dstDbConnectTestButton.Location = New System.Drawing.Point(524, 154)
        Me.dstDbConnectTestButton.Name = "dstDbConnectTestButton"
        Me.dstDbConnectTestButton.Size = New System.Drawing.Size(79, 23)
        Me.dstDbConnectTestButton.TabIndex = 9
        Me.dstDbConnectTestButton.Text = "接続のテスト"
        Me.dstDbConnectTestButton.UseVisualStyleBackColor = True
        '
        'dstInstanceTextBox
        '
        Me.dstInstanceTextBox.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.dstInstanceTextBox.Location = New System.Drawing.Point(91, 39)
        Me.dstInstanceTextBox.MaxLength = 64
        Me.dstInstanceTextBox.Name = "dstInstanceTextBox"
        Me.dstInstanceTextBox.Size = New System.Drawing.Size(200, 19)
        Me.dstInstanceTextBox.TabIndex = 2
        '
        'dstServerTextBox
        '
        Me.dstServerTextBox.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.dstServerTextBox.Location = New System.Drawing.Point(91, 19)
        Me.dstServerTextBox.MaxLength = 64
        Me.dstServerTextBox.Name = "dstServerTextBox"
        Me.dstServerTextBox.Size = New System.Drawing.Size(200, 19)
        Me.dstServerTextBox.TabIndex = 1
        '
        'dstDatabaseComboBox
        '
        Me.dstDatabaseComboBox.FormattingEnabled = True
        Me.dstDatabaseComboBox.Location = New System.Drawing.Point(91, 157)
        Me.dstDatabaseComboBox.Name = "dstDatabaseComboBox"
        Me.dstDatabaseComboBox.Size = New System.Drawing.Size(200, 20)
        Me.dstDatabaseComboBox.TabIndex = 7
        '
        'dstPasswordTextBox
        '
        Me.dstPasswordTextBox.Location = New System.Drawing.Point(176, 133)
        Me.dstPasswordTextBox.Name = "dstPasswordTextBox"
        Me.dstPasswordTextBox.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.dstPasswordTextBox.Size = New System.Drawing.Size(229, 19)
        Me.dstPasswordTextBox.TabIndex = 6
        '
        'dstLoginTextBox
        '
        Me.dstLoginTextBox.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.dstLoginTextBox.Location = New System.Drawing.Point(176, 113)
        Me.dstLoginTextBox.MaxLength = 64
        Me.dstLoginTextBox.Name = "dstLoginTextBox"
        Me.dstLoginTextBox.Size = New System.Drawing.Size(229, 19)
        Me.dstLoginTextBox.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(108, 133)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(79, 21)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "パスワード"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(108, 112)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(79, 21)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "ログイン"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'dstSqlAuthRadioButton
        '
        Me.dstSqlAuthRadioButton.Location = New System.Drawing.Point(92, 88)
        Me.dstSqlAuthRadioButton.Name = "dstSqlAuthRadioButton"
        Me.dstSqlAuthRadioButton.Size = New System.Drawing.Size(167, 21)
        Me.dstSqlAuthRadioButton.TabIndex = 4
        Me.dstSqlAuthRadioButton.TabStop = True
        Me.dstSqlAuthRadioButton.Text = "SQL Server 認証"
        Me.dstSqlAuthRadioButton.UseVisualStyleBackColor = True
        '
        'dstWinAuthRadioButton
        '
        Me.dstWinAuthRadioButton.Location = New System.Drawing.Point(92, 64)
        Me.dstWinAuthRadioButton.Name = "dstWinAuthRadioButton"
        Me.dstWinAuthRadioButton.Size = New System.Drawing.Size(167, 21)
        Me.dstWinAuthRadioButton.TabIndex = 3
        Me.dstWinAuthRadioButton.TabStop = True
        Me.dstWinAuthRadioButton.Text = "Windows 認証"
        Me.dstWinAuthRadioButton.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(6, 158)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(79, 21)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "データベース"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(6, 39)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(79, 21)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "インスタンス名"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(6, 60)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(79, 21)
        Me.Label11.TabIndex = 3
        Me.Label11.Text = "認証"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(6, 18)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(79, 21)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "サーバー"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.CloseButton
        Me.ClientSize = New System.Drawing.Size(633, 430)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.OKButton)
        Me.Controls.Add(Me.CloseButton)
        Me.Controls.Add(Me.GroupBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "R@bitFlow データベースマイグレーションツール"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents srcWinAuthRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents srcSqlAuthRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents srcInstanceTextBox As System.Windows.Forms.TextBox
    Friend WithEvents srcServerTextBox As System.Windows.Forms.TextBox
    Friend WithEvents srcDatabaseComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents srcPasswordTextBox As System.Windows.Forms.TextBox
    Friend WithEvents srcLoginTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents srcDbConnectTestButton As System.Windows.Forms.Button
    Friend WithEvents CloseButton As System.Windows.Forms.Button
    Friend WithEvents OKButton As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents dstDbConnectTestButton As System.Windows.Forms.Button
    Friend WithEvents dstInstanceTextBox As System.Windows.Forms.TextBox
    Friend WithEvents dstServerTextBox As System.Windows.Forms.TextBox
    Friend WithEvents dstDatabaseComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents dstPasswordTextBox As System.Windows.Forms.TextBox
    Friend WithEvents dstLoginTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents dstSqlAuthRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents dstWinAuthRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents srcRenewButton As System.Windows.Forms.Button
    Friend WithEvents dstRenewButton As System.Windows.Forms.Button

End Class
