﻿Option Compare Binary
Option Explicit On
Option Strict On

Imports System
Imports System.Data
Imports System.IO
Imports System.Text
Imports System.Reflection

''' <summary>
''' R@bitFlow データベースの移行定義を管理します。
''' </summary>
''' <remarks></remarks>
Public Class TransferDefinition

#Region " Enum "

    ''' <summary>
    ''' 移行方法を表す列挙値を提供します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum MethodType As Integer

        ''' <summary>
        ''' 全件移行
        ''' </summary>
        ''' <remarks></remarks>
        All = 0

        ''' <summary>
        ''' 差分追加
        ''' </summary>
        ''' <remarks></remarks>
        Add = 1

        ''' <summary>
        ''' 移行対象外
        ''' </summary>
        ''' <remarks></remarks>
        None = 9

    End Enum

#End Region

#Region " Fields "

    ''' <summary>
    ''' 移行定義テーブル
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared _defineTable As DataTable

#End Region

#Region " Constructor "

    ''' <summary>
    ''' LogManager クラスの新しいインスタンスを初期化します。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub New()

    End Sub

#End Region

#Region " Public Property "

#Region " DefineTables "

    ''' <summary>
    ''' 移行方法を定義したテーブルを取得します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared ReadOnly Property DefineTables() As DataTable
        Get
            Return _defineTable
        End Get
    End Property

#End Region

#End Region

#Region " Public Method "

#Region " Initialize "

    ''' <summary>
    ''' このクラスのインスタンスを初期化します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Sub Initialize()

        Try
            Dim defineFile As String = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), My.Settings.defineFile)
            Dim ds As New DataSet()
            ds.ReadXml(defineFile)
            _defineTable = ds.Tables(0)
        Catch ex As Exception
            Throw
        End Try

    End Sub

#End Region

#Region " GetMethodType "

    ''' <summary>
    ''' 指定した定義行から、移行方法を取得します。
    ''' </summary>
    ''' <param name="row">移行定義行</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function GetMethodType(ByVal row As DataRow) As MethodType
        Return CType(row.Item("method"), MethodType)
    End Function

#End Region

#End Region

End Class
