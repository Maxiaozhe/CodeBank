﻿Option Compare Binary
Option Explicit On
Option Strict On

Imports System
Imports System.Data.SqlClient

''' <summary>
''' SQL Server へ接続したり Transact-SQL を実行するためのプロパティやメソッドを提供します。
''' </summary>
''' <remarks></remarks>
Public Class SqlDatabase
    Implements IDisposable

#Region " Enum "

    ''' <summary>
    ''' SQL Server への認証方法を表す列挙値を提供します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum SqlAuthenticationMode

        ''' <summary>
        ''' Windows 認証
        ''' </summary>
        ''' <remarks></remarks>
        Windows

        ''' <summary>
        ''' SQL Server 認証
        ''' </summary>
        ''' <remarks></remarks>
        SQLServer

    End Enum

#End Region

#Region " Structure "

    ''' <summary>
    ''' SQL Server へ接続するための認証情報を提供します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Structure SqlConnectionInfo

#Region " Fields "

        ''' <summary>
        ''' SQL Server 認証用データベース接続文字列テンプレート
        ''' </summary>
        ''' <remarks></remarks>
        Private Const SQL_AUTH_CN_STR_TEMPLATE As String = "Data Source={0};Persist Security Info=False;User ID={1};Password={2};Initial Catalog={3};Connect Timeout={4};"

        ''' <summary>
        ''' Windows 認証用データベース接続文字列テンプレート
        ''' </summary>
        ''' <remarks></remarks>
        Private Const WIN_AUTH_CN_STR_TEMPLATE As String = "Data Source={0};Persist Security Info=False;Integrated Security=SSPI;Initial Catalog={1};Connect Timeout={2};"

        ''' <summary>
        ''' サーバー名またはアドレス
        ''' </summary>
        ''' <remarks></remarks>
        Private _server As String

        ''' <summary>
        ''' インスタンス名
        ''' </summary>
        ''' <remarks></remarks>
        Private _instance As String

        ''' <summary>
        ''' SQL Server への認証方法
        ''' </summary>
        ''' <remarks></remarks>
        Private _authMode As SqlAuthenticationMode

        ''' <summary>
        ''' SQL Server 認証時のログイン
        ''' </summary>
        ''' <remarks></remarks>
        Private _userId As String

        ''' <summary>
        ''' SQL Server 認証ログインのパスワード
        ''' </summary>
        ''' <remarks></remarks>
        Private _password As String

        ''' <summary>
        ''' データベース名
        ''' </summary>
        ''' <remarks></remarks>
        Private _databaseName As String

#End Region

#Region " Constructor "

        ''' <summary>
        ''' ConnectionInfo 構造体のインスタンスを、指定したログインの SQL Server 認証で初期化します。
        ''' </summary>
        ''' <param name="server">SQL Server 名またはアドレス</param>
        ''' <param name="userId">SQL Server 認証で使用するログイン</param>
        ''' <param name="password">ログインのパスワード</param>
        ''' <param name="database">接続先データベース名</param>
        ''' <remarks></remarks>
        Public Sub New(ByVal server As String, ByVal userId As String, ByVal password As String, ByVal database As String)
            _server = server
            _instance = String.Empty
            _authMode = SqlAuthenticationMode.SQLServer
            _userId = userId
            _password = password
            _databaseName = database
        End Sub

        ''' <summary>
        ''' ConnectionInfo 構造体のインスタンスを、Windows 認証モードで初期化します。
        ''' </summary>
        ''' <param name="server">SQL Server 名またはアドレス</param>
        ''' <param name="database">接続先データベース名</param>
        ''' <remarks></remarks>
        Public Sub New(ByVal server As String, ByVal database As String)
            _server = server
            _instance = String.Empty
            _authMode = SqlAuthenticationMode.Windows
            _userId = String.Empty
            _password = String.Empty
            _databaseName = database
        End Sub

#End Region

#Region " Properties "

#Region " Server "

        ''' <summary>
        ''' 接続する SQL Server のサーバー名またはアドレスを取得または設定します。
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Server() As String
            Get
                Return _server
            End Get
            Set(ByVal value As String)
                _server = value
            End Set
        End Property

#End Region

#Region " Instance "

        ''' <summary>
        ''' 接続する SQL Server のインスタンス名を取得または設定します。
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Instance() As String
            Get
                Return _instance
            End Get
            Set(ByVal value As String)
                _instance = value
            End Set
        End Property

#End Region

#Region " AuthenticationMode "

        ''' <summary>
        ''' SQL Server への認証方法を取得または設定します。
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property AuthenticationMode() As SqlAuthenticationMode
            Get
                Return _authMode
            End Get
            Set(ByVal value As SqlAuthenticationMode)
                _authMode = value
            End Set
        End Property

#End Region

#Region " UserId "

        ''' <summary>
        ''' SQL Server 認証時のログインを取得または設定します。
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property UserId() As String
            Get
                Return _userId
            End Get
            Set(ByVal value As String)
                _userId = value
                _authMode = SqlAuthenticationMode.SQLServer
            End Set
        End Property

#End Region

#Region " Password "

        ''' <summary>
        ''' SQL Server 認証ログインのパスワードを取得または設定します。
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property Password() As String
            Get
                Return _password
            End Get
            Set(ByVal value As String)
                _password = value
                _authMode = SqlAuthenticationMode.SQLServer
            End Set
        End Property

#End Region

#Region " DatabaseName "

        ''' <summary>
        ''' 接続するデータベース名を取得または設定します。
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public Property DatabaseName() As String
            Get
                Return _databaseName
            End Get
            Set(ByVal value As String)
                _databaseName = value
            End Set
        End Property

#End Region

#Region " ConnectionString "

        ''' <summary>
        ''' データベースに接続するための文字列を取得します。
        ''' </summary>
        ''' <value></value>
        ''' <returns></returns>
        ''' <remarks></remarks>
        Public ReadOnly Property ConnectionString() As String
            Get
                Dim dataSource As String = _server
                If Not _instance.Equals(String.Empty) Then dataSource &= "\" & _instance

                Dim cnStr As String = String.Empty
                Dim formatArgs As String()

                Select Case _authMode
                    Case SqlAuthenticationMode.Windows
                        formatArgs = New String() {dataSource, _databaseName, My.Settings.connectionTimeout.ToString()}
                        cnStr = String.Format(WIN_AUTH_CN_STR_TEMPLATE, formatArgs)
                    Case SqlAuthenticationMode.SQLServer
                        formatArgs = New String() {dataSource, _userId, _password, _databaseName, My.Settings.connectionTimeout.ToString()}
                        cnStr = String.Format(SQL_AUTH_CN_STR_TEMPLATE, formatArgs)
                End Select

                Return cnStr
            End Get
        End Property

#End Region

#End Region

    End Structure

#End Region

#Region " Fields "

    ''' <summary>
    ''' SQL Server コネクション
    ''' </summary>
    ''' <remarks></remarks>
    Private _cn As SqlConnection

    ''' <summary>
    ''' トランザクション
    ''' </summary>
    ''' <remarks></remarks>
    Private _tran As SqlTransaction

    ''' <summary>
    ''' データベース接続文字列
    ''' </summary>
    ''' <remarks></remarks>
    Private _connectionString As String

#End Region

#Region " Constructor "

    ''' <summary>
    ''' SqlDatabase クラスの新しいインスタンスを初期化します。
    ''' </summary>
    ''' <param name="connectionInfo">SQL Server への接続情報</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal connectionInfo As SqlConnectionInfo)
        _connectionString = connectionInfo.ConnectionString
        _cn = New SqlConnection(_connectionString)
    End Sub

#End Region

#Region " Public Property "

#Region " ConnectionString "

    ''' <summary>
    ''' データベース接続文字列を取得します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ConnectionString() As String
        Get
            Return _connectionString
        End Get
    End Property

#End Region

#Region " Connection "

    ''' <summary>
    ''' SQL Server への開いた接続を取得します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Connection() As SqlConnection
        Get
            Return _cn
        End Get
    End Property

#End Region

#Region " Executor "

    ''' <summary>
    ''' SQL Server で Transact-SQL を実行するための SqlExecutor クラスのインスタンスを取得します。
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property Executor() As SqlExecutor
        Get
            Return New SqlExecutor(Me)
        End Get
    End Property

#End Region

#End Region

#Region " Public Method "

#Region " Open "

    ''' <summary>
    ''' データベースの接続を開きます。
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Open()
        Open(False)
    End Sub

    ''' <summary>
    ''' データベースの接続を開きます。
    ''' </summary>
    ''' <param name="transaction">トランザクションを開始するかどうか</param>
    ''' <remarks></remarks>
    Public Sub Open(ByVal transaction As Boolean)

        Try
            _cn.Open()

            'トランザクションを開始する
            If transaction Then _tran = _cn.BeginTransaction()
        Catch ex As Exception
            Throw
        End Try

    End Sub

#End Region

#Region " Close "

    ''' <summary>
    ''' データベースへの接続を終了します。
    ''' 途中のトランザクションはロールバックされます。
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Close()

        Try
            'トランザクション中はロールバック
            If _tran IsNot Nothing Then _tran.Rollback()
            _tran = Nothing

            If _cn IsNot Nothing AndAlso _cn.State <> ConnectionState.Closed Then _cn.Close()
            _cn = Nothing
        Catch ex As Exception
            Throw
        End Try

    End Sub

#End Region

#Region " BeginTransaction "

    ''' <summary>
    ''' トランザクションを開始します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub BeginTransaction()
        _tran = _cn.BeginTransaction()
    End Sub

#End Region

#Region " CommitTransaction "

    ''' <summary>
    ''' トランザクションをコミットします。
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub CommitTransaction()
        _tran.Commit()
        _tran = Nothing
    End Sub

#End Region

#Region " RollbackTransaction "

    ''' <summary>
    ''' トランザクションをロールバックします。
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub RollbackTransaction()
        _tran.Rollback()
        _tran = Nothing
    End Sub

#End Region

#Region " TryConnect "

    ''' <summary>
    ''' 指定した接続情報で、データベースへの接続を試みます。
    ''' 接続に失敗した場合は False を返します。
    ''' </summary>
    ''' <param name="connectionInfo">データベースへの接続情報</param>
    ''' <param name="e">接続に失敗したときの例外</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function TryConnect(ByVal connectionInfo As SqlConnectionInfo, ByRef e As Exception) As Boolean

        Dim isConnected As Boolean
        Using db As New SqlDatabase(connectionInfo)

            '接続してみる
            Try
                db.Open()

                isConnected = True
            Catch ex As Exception
                e = ex
                isConnected = False
            End Try

            '接続に成功した場合は、データベースへの接続を終了する
            If isConnected Then db.Close()
        End Using

        Return isConnected

    End Function

#End Region

#Region " CreateCommand "

    ''' <summary>
    ''' データベースで実行するコマンドオブジェクトを生成して返します。
    ''' </summary>
    ''' <param name="commandText">実行するコマンド</param>
    ''' <returns>データベースコネクションに関連付けられたコマンドオブジェクトを返します。</returns>
    ''' <remarks></remarks>
    Public Function CreateCommand(ByVal commandText As String) As SqlCommand

        Try
            Dim cmd As SqlCommand = _cn.CreateCommand()
            cmd.CommandText = commandText
            cmd.CommandType = CommandType.Text
            cmd.CommandTimeout = Int32.Parse(My.Settings.commandTimeout)

            If _tran IsNot Nothing Then cmd.Transaction = _tran

            Return cmd
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#End Region

#Region " Implement Interface "

#Region " IDisposable "

    Private disposedValue As Boolean = False        ' 重複する呼び出しを検出するには

    ' IDisposable
    Protected Overridable Sub Dispose(ByVal disposing As Boolean)
        If Not Me.disposedValue Then
            If disposing Then
                ' TODO: 他の状態を解放します (マネージ オブジェクト)。
            End If

            ' TODO: ユーザー独自の状態を解放します (アンマネージ オブジェクト)。
            ' TODO: 大きなフィールドを null に設定します。
            Close()
        End If
        Me.disposedValue = True
    End Sub

#Region " IDisposable Support "
    ' このコードは、破棄可能なパターンを正しく実装できるように Visual Basic によって追加されました。
    Public Sub Dispose() Implements IDisposable.Dispose
        ' このコードを変更しないでください。クリーンアップ コードを上の Dispose(ByVal disposing As Boolean) に記述します。
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub
#End Region

#End Region

#End Region

End Class
