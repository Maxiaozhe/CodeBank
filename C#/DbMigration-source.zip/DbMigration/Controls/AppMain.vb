﻿Option Compare Binary
Option Explicit On
Option Strict On

Imports System
Imports System.IO
Imports System.Threading
Imports System.Windows.Forms

''' <summary>
''' R@bitFlow データベースを新しいデータベースに移行するツールです。
''' </summary>
''' <remarks></remarks>
Public Class AppMain

#Region "二重起動確認用プロパティ"

    '二重起動の禁止
    Private Shared _prevInstance As System.Threading.Mutex
    Private Shared ReadOnly Property PrevInstance() As Boolean
        Get
            If _prevInstance Is Nothing Then _prevInstance = New Mutex(False, Application.ProductName)

            If _prevInstance.WaitOne(0, False) = False Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

#End Region

    ''' <summary>
    ''' アプリケーションのメインエントリポイントです。
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Sub Main()

        Try
            '二重起動禁止
            If PrevInstance Then Return

            ' Vista スタイル
            System.Windows.Forms.Application.EnableVisualStyles()

            'アプリケーションで使用する各リソースの初期化
            TransferDefinition.Initialize()
            LogManager.Initialize()

            'アプリケーションの開始
            Application.Run(New MainForm())
        Catch ex As Exception
            MessageBox.Show(ex.Message, Application.ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

End Class
