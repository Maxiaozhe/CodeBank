﻿Option Compare Binary
Option Explicit On
Option Strict On

''' <summary>
''' R@bitFlow データベースの移行管理クラスです。
''' </summary>
''' <remarks></remarks>
Public Class TransferManager
    Implements IDisposable

#Region " Structure "

#Region " TranferResult "

    ''' <summary>
    ''' 移行結果を格納する構造体を提供します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Structure TranferResult

        ''' <summary>
        ''' 移行が正常に完了したかどうかを取得します。
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly IsSuccess As Boolean

        ''' <summary>
        ''' 移行に成功したオブジェクトの件数を取得します。
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly SuccessObjectCount As Integer

        ''' <summary>
        ''' 移行に失敗したオブジェクトの件数を取得します。
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly FailedObjectCount As Integer

        ''' <summary>
        ''' 失敗時に発生した例外
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly e As Exception

        ''' <summary>
        ''' TranferResult 構造体のインスタンスを初期化します。
        ''' </summary>
        ''' <param name="successCount">移行に成功したオブジェクトの件数</param>
        ''' <param name="failedCount">移行に失敗したオブジェクトの件数</param>
        ''' <remarks></remarks>
        Friend Sub New(ByVal successCount As Integer, ByVal failedCount As Integer)
            IsSuccess = True
            SuccessObjectCount = successCount
            FailedObjectCount = failedCount
            e = Nothing
        End Sub

        ''' <summary>
        ''' TranferResult 構造体のインスタンスを初期化します。
        ''' </summary>
        ''' <param name="ex">例外</param>
        ''' <remarks></remarks>
        Friend Sub New(ByVal ex As Exception)
            IsSuccess = False
            SuccessObjectCount = 0
            FailedObjectCount = 0
            e = ex
        End Sub

    End Structure

#End Region

#Region " MoveResult "

    ''' <summary>
    ''' 移行したオブジェクトの件数を提供します。
    ''' </summary>
    ''' <remarks></remarks>
    Private Structure TransferObjectCountInfo

        ''' <summary>
        ''' 移行に成功したオブジェクトの件数
        ''' </summary>
        ''' <remarks></remarks>
        Friend ReadOnly SuccessObjectCount As Integer

        ''' <summary>
        ''' 移行に失敗したオブジェクトの件数
        ''' </summary>
        ''' <remarks></remarks>
        Friend ReadOnly FailedObjectCount As Integer

        ''' <summary>
        ''' TransferObjectCountInfo 構造体のインスタンスを初期化します。
        ''' </summary>
        ''' <param name="successCount">成功件数</param>
        ''' <param name="failedCount">失敗件数</param>
        ''' <remarks></remarks>
        Friend Sub New(ByVal successCount As Integer, ByVal failedCount As Integer)
            SuccessObjectCount = successCount
            FailedObjectCount = failedCount
        End Sub

    End Structure

#End Region

#Region " ReportArgs "

    ''' <summary>
    ''' 進捗レポートの情報を提供します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Class ReportArgs

        ''' <summary>
        ''' 進捗率
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly Percent As Integer

        ''' <summary>
        ''' メッセージ
        ''' </summary>
        ''' <remarks></remarks>
        Public ReadOnly Message As String

        ''' <summary>
        ''' ReportArgs クラスの新しいインスタンスを初期化します。
        ''' </summary>
        ''' <param name="p">進捗率</param>
        ''' <param name="objectName">オブジェクト名</param>
        ''' <param name="objectType">オブジェクトタイプ</param>
        ''' <remarks></remarks>
        Friend Sub New(ByVal p As Integer, ByVal objectName As String, ByVal objectType As TranferObjectType)
            Dim args As String() = New String() {My.Resources.TransferObjectType.ResourceManager.GetString(objectType.ToString()), objectName}
            Message = String.Format(My.Resources.Informations.ResourceManager.GetString(Informations.TransferInformation.ToString()), args)
            Percent = p
        End Sub

    End Class

#End Region

#End Region

#Region " Fields "

    ''' <summary>
    ''' 進捗報告イベントハンドラ
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Public Delegate Sub ProcessReportEventHandler(ByVal sender As Object, ByVal e As ReportArgs)

    ''' <summary>
    ''' 移行元データベースへの接続
    ''' </summary>
    ''' <remarks></remarks>
    Private _srcDatabase As SqlDatabase

    ''' <summary>
    ''' 移行先データベースへの接続
    ''' </summary>
    ''' <remarks></remarks>
    Private _dstDatabase As SqlDatabase

    ''' <summary>
    ''' 移行対象の総オブジェクト数
    ''' </summary>
    ''' <remarks></remarks>
    Private _totalObjectCount As Integer

    ''' <summary>
    ''' 移行オブジェクトのカウント
    ''' </summary>
    ''' <remarks></remarks>
    Private _objectCounter As Integer

    ''' <summary>
    ''' 進捗報告イベントハンドラ
    ''' </summary>
    ''' <remarks></remarks>
    Private _processReport As ProcessReportEventHandler

#End Region

#Region " Constructor "

    ''' <summary>
    ''' TransferManager クラスの新しいインスタンスを初期化します。
    ''' </summary>
    ''' <param name="srcConnectionInfo">移行元データベースへの接続情報</param>
    ''' <param name="dstConnectionInfo">移行先データベースへの接続情報</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal srcConnectionInfo As SqlDatabase.SqlConnectionInfo, ByVal dstConnectionInfo As SqlDatabase.SqlConnectionInfo)
        _srcDatabase = New SqlDatabase(srcConnectionInfo)
        _dstDatabase = New SqlDatabase(dstConnectionInfo)

        _srcDatabase.Open()
        _dstDatabase.Open()
    End Sub

#End Region

#Region " Public Method "

#Region " Close "

    ''' <summary>
    ''' データベースへの接続を切断し、移行を終了します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Close()

        Try
            If _srcDatabase IsNot Nothing Then _srcDatabase.Close()
            If _dstDatabase IsNot Nothing Then _dstDatabase.Close()

            _srcDatabase = Nothing
            _dstDatabase = Nothing
        Catch ex As Exception
            Throw
        End Try

    End Sub

#End Region

#Region " Execute "

    ''' <summary>
    ''' データベースの移行を実行します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function Execute(ByVal ProcessReport As ProcessReportEventHandler) As TranferResult

        Try
            '移行対象オブジェクトの取得
            Dim tables As List(Of String) = _srcDatabase.Executor.SelectSrouceTables()
            Dim functions As List(Of String) = _srcDatabase.Executor.SelectSourceFunctions()
            Dim views As List(Of String) = _srcDatabase.Executor.SelectViews()
            Dim procedures As List(Of String) = _srcDatabase.Executor.SelectSourceProcedures()

            'メンバフィールドの初期化
            _processReport = ProcessReport
            _objectCounter = 0
            _totalObjectCount = tables.Count + views.Count + procedures.Count + functions.Count

            Dim result As TransferObjectCountInfo
            Dim successCount As Integer = 0
            Dim failedCount As Integer = 0

            'テーブルの移行
            result = MoveTables(tables)
            successCount += result.SuccessObjectCount
            failedCount += result.FailedObjectCount

            'ファンクションの移行
            result = MoveFunctions(functions)
            successCount += result.SuccessObjectCount
            failedCount += result.FailedObjectCount

            'ビューの移行
            result = MoveViews(views)
            successCount += result.SuccessObjectCount
            failedCount += result.FailedObjectCount

            'ストアドプロシージャの移行
            result = MoveProcedures(procedures)
            successCount += result.SuccessObjectCount
            failedCount += result.FailedObjectCount

            'フォームファイルの名前空間変更(V6対応)
            ChaneNameSpame()

            Return New TranferResult(successCount, failedCount)
        Catch ex As Exception
            LogManager.Append(ex)
            Return New TranferResult(ex)
        End Try

    End Function

#End Region

#End Region

#Region " Private Method "

#Region " GetException "

    ''' <summary>
    ''' アプリケーション例外を取得します。
    ''' </summary>
    ''' <param name="messageType">例外メッセージ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetException(ByVal messageType As Exceptions, ByVal ParamArray formatArgs As String()) As ApplicationException
        Dim message As String = My.Resources.Exceptions.ResourceManager.GetString(messageType.ToString())
        If formatArgs IsNot Nothing AndAlso formatArgs.Length <> 0 Then message = String.Format(message, formatArgs)
        Return New ApplicationException(message)
    End Function

#End Region

#Region " MoveTables "

    ''' <summary>
    ''' テーブルを移行します。
    ''' </summary>
    ''' <param name="tables">移行対象テーブル</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MoveTables(ByVal tables As List(Of String)) As TransferObjectCountInfo

        Dim successCount As Integer = 0
        Dim failedCount As Integer = 0

        Try
            For Each tableName As String In _srcDatabase.Executor.SelectSrouceTables()
                'メッセージの通知
                _objectCounter += 1
                InvokeProcessReport(_objectCounter, tableName, TranferObjectType.Table)

                Dim result As Boolean = MoveTable(tableName)

                If result Then
                    successCount += 1
                Else
                    failedCount += 1
                End If
            Next
        Catch ex As Exception
            Throw
        End Try

        Return New TransferObjectCountInfo(successCount, failedCount)

    End Function

#End Region

#Region " MoveProcedures "

    ''' <summary>
    ''' ストアドプロシージャを移行します。
    ''' </summary>
    ''' <param name="procedures">移行対象プロシージャ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MoveProcedures(ByVal procedures As List(Of String)) As TransferObjectCountInfo

        Dim successCount As Integer = 0
        Dim failedCount As Integer = 0

        Try
            For Each procedureName As String In procedures
                'メッセージの通知
                _objectCounter += 1
                InvokeProcessReport(_objectCounter, procedureName, TranferObjectType.StoredProcedure)

                Dim result As Boolean = MoveProcedure(procedureName)

                If result Then
                    successCount += 1
                Else
                    failedCount += 1
                End If
            Next
        Catch ex As Exception
            Throw
        End Try

        Return New TransferObjectCountInfo(successCount, failedCount)

    End Function

#End Region

#Region " MoveFunctions "

    ''' <summary>
    ''' 移行元データベースのすべてのストアドファンクションを移行します。
    ''' </summary>
    ''' <param name="functions">移行対象関数</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MoveFunctions(ByVal functions As List(Of String)) As TransferObjectCountInfo

        Dim successCount As Integer = 0
        Dim failedCount As Integer = 0

        Try
            For Each functionName As String In functions
                'メッセージの通知
                _objectCounter += 1
                InvokeProcessReport(_objectCounter, functionName, TranferObjectType.StoredFunction)

                Dim result As Boolean = MoveFunction(functionName)

                If result Then
                    successCount += 1
                Else
                    failedCount += 1
                End If
            Next
        Catch ex As Exception
            Throw
        End Try

        Return New TransferObjectCountInfo(successCount, failedCount)

    End Function

#End Region

#Region " MoveViews "

    ''' <summary>
    ''' 移行元データベースのすべてのビューを移行します。
    ''' </summary>
    ''' <param name="views">移行対象ビュー</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MoveViews(ByVal views As List(Of String)) As TransferObjectCountInfo

        Dim successCount As Integer = 0
        Dim failedCount As Integer = 0

        Try
            For Each viewName As String In views
                'メッセージの通知
                _objectCounter += 1
                InvokeProcessReport(_objectCounter, viewName, TranferObjectType.StoredFunction)

                Dim result As Boolean = MoveView(viewName)

                If result Then
                    successCount += 1
                Else
                    failedCount += 1
                End If
            Next
        Catch ex As Exception
            Throw
        End Try

        Return New TransferObjectCountInfo(successCount, failedCount)

    End Function

#End Region

#Region " MoveTable "

    ''' <summary>
    ''' 指定したテーブルを、移行先データベースに移行します。
    ''' </summary>
    ''' <param name="tableName">テーブル名</param>
    ''' <returns>移行に成功した場合は True を、失敗した場合は False を返します。</returns>
    ''' <remarks></remarks>
    Private Function MoveTable(ByVal tableName As String) As Boolean

        Try
            '移行定義を参照し、移行対象テーブルかどうかを確認する（複数件見つかった場合は失敗とする）
            Dim findRows As DataRow() = TransferDefinition.DefineTables.Select(String.Format("name='{0}'", tableName))
            If findRows.Length > 1 Then
                Throw GetException(Exceptions.MultiDefineFound)
                Return False
            End If

            '移行方法を取得する
            Dim method As TransferDefinition.MethodType
            If findRows.Length = 1 Then
                method = TransferDefinition.GetMethodType(findRows(0))
            Else
                method = TransferDefinition.MethodType.All
            End If

            '移行方法が「移行対象外」の場合は処理を抜ける
            If method = TransferDefinition.MethodType.None Then
                LogManager.Append(tableName, TranferObjectType.Table, LogManager.OperationType.Skip)
                Return True
            End If

            'テーブルが存在しない場合は、テーブルを作る
            If Not _dstDatabase.Executor.ExistTable(tableName) Then CreateTable(tableName)

            Select Case method
                Case TransferDefinition.MethodType.All : TransferAll(tableName)
                Case TransferDefinition.MethodType.Add : TransferDefference(tableName, findRows(0))
            End Select

            'インデックスを再構築する
            If Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings("rebuildIndex")) Then _dstDatabase.Executor.RebuildIndex(tableName)

            LogManager.Append(tableName, method)

            Return True
        Catch ex As Exception
            LogManager.Append(ex)
            LogManager.Append(tableName, TranferObjectType.Table, False)

            Return False
        End Try

    End Function

#End Region

#Region " MoveProcedure "

    ''' <summary>
    ''' 指定したストアドプロシージャを、移行先データベースに移行します。
    ''' </summary>
    ''' <param name="procedureName">ストアドプロシージャ名</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MoveProcedure(ByVal procedureName As String) As Boolean

        Dim result As Boolean

        Try
            'ストアドプロシージャが存在する場合は処理を抜ける（移行しない）
            If _dstDatabase.Executor.ExistProcedure(procedureName) Then
                LogManager.Append(procedureName, TranferObjectType.StoredProcedure, LogManager.OperationType.Skip)
                Return True
            End If

            'CREATE スクリプトを取得する
            Dim createCommand As String = _srcDatabase.Executor.GetCreateProcedureScript(procedureName)

            '移行先データベースにプロシージャを作成する
            _dstDatabase.Executor.ExecuteNonQuery(createCommand)

            result = True
        Catch ex As Exception
            LogManager.Append(ex)
            result = False
        End Try

        LogManager.Append(procedureName, TranferObjectType.StoredProcedure, result)
        Return result

    End Function

#End Region

#Region " MoveFunction "

    ''' <summary>
    ''' 指定したストアドファンクションを、移行先データベースに移行します。
    ''' </summary>
    ''' <param name="functionName">ストアドプロシージャ名</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MoveFunction(ByVal functionName As String) As Boolean

        Dim result As Boolean

        Try
            'ストアドファンクションが存在する場合は処理を抜ける（移行しない）
            If _dstDatabase.Executor.ExistFunction(functionName) Then
                LogManager.Append(functionName, TranferObjectType.StoredFunction, LogManager.OperationType.Skip)
                Return True
            End If

            'CREATE スクリプトを取得する
            Dim createCommand As String = _srcDatabase.Executor.GetCreateFunctionScript(functionName)

            '移行先データベースにプロシージャを作成する
            _dstDatabase.Executor.ExecuteNonQuery(createCommand)

            result = True
        Catch ex As Exception
            LogManager.Append(ex)
            result = False
        End Try

        LogManager.Append(functionName, TranferObjectType.StoredFunction, result)
        Return result

    End Function

#End Region

#Region " MoveView "

    ''' <summary>
    ''' 指定したビューを、移行先データベースに移行します。
    ''' </summary>
    ''' <param name="viewName">ビュー名</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MoveView(ByVal viewName As String) As Boolean

        Dim result As Boolean

        Try
            'ビューが存在する場合は処理を抜ける（移行しない）
            If _dstDatabase.Executor.ExistView(viewName) Then
                LogManager.Append(viewName, TranferObjectType.View, LogManager.OperationType.Skip)
                Return True
            End If

            'CREATE スクリプトを取得する
            Dim createCommand As String = _srcDatabase.Executor.GetCreateViewScript(viewName)

            '移行先データベースにプロシージャを作成する
            _dstDatabase.Executor.ExecuteNonQuery(createCommand)

            result = True
        Catch ex As Exception
            LogManager.Append(ex)
            result = False
        End Try

        LogManager.Append(viewName, TranferObjectType.View, result)
        Return result

    End Function

#End Region

#Region " CreateTableScript "

    ''' <summary>
    ''' 指定したテーブルを、移行元データベースに作成します。
    ''' </summary>
    ''' <param name="tableName">テーブル名</param>
    ''' <remarks></remarks>
    Private Sub CreateTable(ByVal tableName As String)

        Dim script As String = String.Empty

        Try
            'テーブルの作成
            script = GetTableScript(tableName)
            _dstDatabase.Executor.ExecuteNonQuery(script)

            'インデックスの作成
            For Each dr As DataRow In _srcDatabase.Executor.SelectIndexes(tableName).Rows
                script = GetIndexScript(tableName, Int32.Parse(dr.Item(0).ToString()), dr.Item(1).ToString(), dr.Item(2).ToString().Equals("1"))
                _dstDatabase.Executor.ExecuteNonQuery(script)
            Next

            'デフォルトバインドの作成
            For Each dr As DataRow In _srcDatabase.Executor.SelectColumns(tableName).Rows
                Dim defaultName As String = dr.Item(3).ToString()
                If defaultName.Equals(String.Empty) Then Continue For
                script = GetDefaultBindScript(tableName, dr.Item(0).ToString(), defaultName)
                _dstDatabase.Executor.ExecuteNonQuery(script)
            Next
        Catch ex As Exception
            Throw
        End Try

    End Sub

#End Region

#Region " GetTableScript "

    ''' <summary>
    ''' テーブル作成スクリプトを取得します。
    ''' </summary>
    ''' <param name="tableName">テーブル名</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetTableScript(ByVal tableName As String) As String

        Try
            Dim script As New System.Text.StringBuilder()
            For Each dr As DataRow In _srcDatabase.Executor.SelectColumns(tableName).Rows
                If script.Length <> 0 Then script.AppendLine(",")

                Dim nullable As String = String.Empty
                If Int32.Parse(dr.Item(4).ToString()) = 0 Then
                    nullable = "NOT NULL"
                Else
                    nullable = "NULL"
                End If

                Dim dataType As String = String.Empty
                Dim size As Integer = Int32.Parse(dr.Item(2).ToString())
                If size = 0 OrElse dr.Item(5).ToString().Equals(String.Empty) Then
                    dataType = String.Format("[{0}]", dr.Item(1).ToString())
                Else
                    Dim sizeArg As String = size.ToString()
                    If size < 0 Then sizeArg = "MAX"

                    dataType = String.Format("[{0}]({1})", dr.Item(1).ToString(), sizeArg)
                End If

                Dim formatArgs As String() = New String() {dr.Item(0).ToString(), dataType, nullable}
                Dim column As String = String.Format("[{0}] {1} {2}", formatArgs)

                script.Append(ControlChars.Tab & column)
            Next

            Return String.Format("CREATE TABLE [{0}]({1})", tableName, script.ToString())
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " GetIndexScript "

    ''' <summary>
    ''' インデックス作成スクリプトを取得します。
    ''' </summary>
    ''' <param name="tableName">テーブル名</param>
    ''' <param name="indexId">インデックスID</param>
    ''' <param name="indexName">インデックス名</param>
    ''' <param name="isPrimary">プライマリキーかどうか</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetIndexScript(ByVal tableName As String, ByVal indexId As Integer, ByVal indexName As String, ByVal isPrimary As Boolean) As String

        Dim script As New System.Text.StringBuilder()

        Try
            Dim indexFields As String = String.Empty
            For Each dr As DataRow In _srcDatabase.Executor.SelectIndexColumns(tableName, indexId).Rows
                If Not indexFields.Equals(String.Empty) Then indexFields &= ","

                Dim template As String = String.Empty
                If Convert.ToBoolean(dr.Item(1).ToString()) Then
                    template = "[{0}] DESC"
                Else
                    template = "[{0}] ASC"
                End If

                indexFields &= String.Format(template, dr.Item(0).ToString())
            Next

            Dim formatArgs As String() = New String() {indexName, tableName, indexFields}
            If isPrimary Then
                Return String.Format("ALTER TABLE [{1}] WITH NOCHECK ADD CONSTRAINT [{0}] PRIMARY KEY CLUSTERED({2}) ON [PRIMARY]", formatArgs)
            Else
                Return String.Format("CREATE INDEX [{0}] ON [{1}]({2}) ON [PRIMARY]", formatArgs)
            End If
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " GetDefaultBindScript "

    ''' <summary>
    ''' デフォルトバインドスクリプトを取得します。
    ''' </summary>
    ''' <param name="tableName">テーブル名</param>
    ''' <param name="columnName">カラム名</param>
    ''' <param name="defaultName">デフォルト名</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDefaultBindScript(ByVal tableName As String, ByVal columnName As String, ByVal defaultName As String) As String

        Try
            Dim formatArgs As String() = New String() {defaultName, tableName, columnName}
            Return String.Format("EXEC sp_bindefault N'[{0}]', N'[{1}].[{2}]'", formatArgs)
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " TransferAll "

    ''' <summary>
    ''' 指定したテーブルの移行元データベースにあるすべてのデータを、移行先データベースにコピーします。
    ''' </summary>
    ''' <param name="tableName">テーブル名</param>
    ''' <remarks></remarks>
    Private Sub TransferAll(ByVal tableName As String)

        Dim schema As DataTable = _dstDatabase.Executor.GetTableSchema(tableName)
        Dim existsIdentiry As Boolean = AutoIncrement(schema)

        Try
            '既存データの全件削除（移行先データベース）
            _dstDatabase.Executor.TruncateTable(tableName)

            'テーブルに自動採番列が含まれている場合は IDENTITY_INSERT オプションを有効にする
            If existsIdentiry Then _dstDatabase.Executor.SetIdentityInsert(tableName, SqlExecutor.IdentityInsertOptionFlag.On)

            'データの移行
            Using srcReader As SqlClient.SqlDataReader = _srcDatabase.Executor.ExecuteReader(String.Format("SELECT * FROM [{0}]", tableName))
                Dim bulkCopy As SqlClient.SqlBulkCopy
                If existsIdentiry Then
                    bulkCopy = New SqlClient.SqlBulkCopy(_dstDatabase.ConnectionString, SqlClient.SqlBulkCopyOptions.KeepIdentity)
                Else
                    bulkCopy = New SqlClient.SqlBulkCopy(_dstDatabase.Connection)
                End If

                bulkCopy.BatchSize = Int32.Parse(My.Settings.bulkCopyBatchSize)
                bulkCopy.BulkCopyTimeout = Int32.Parse(My.Settings.bulkCopyTimeout)
                bulkCopy.DestinationTableName = tableName
                bulkCopy.WriteToServer(srcReader)

                srcReader.Close()
            End Using
        Catch ex As Exception
            Throw
        Finally
            'テーブルに自動採番列が含まれている場合は IDENTITY_INSERT オプションを無効にする
            If existsIdentiry Then _dstDatabase.Executor.SetIdentityInsert(tableName, SqlExecutor.IdentityInsertOptionFlag.Off)
        End Try

    End Sub

#End Region

#Region " TransferDifference "

    ''' <summary>
    ''' 移行先テーブルに存在しないデータのみ、移行元からコピーします。
    ''' </summary>
    ''' <param name="tableName">テーブル名</param>
    ''' <param name="define">移行定義</param>
    ''' <remarks></remarks>
    Private Sub TransferDefference(ByVal tableName As String, ByVal define As DataRow)

        Try
            Dim fields As String = define.Item("fields").ToString()
            Dim selectCommand As String
            If fields.Equals(String.Empty) Then
                selectCommand = String.Format("SELECT * FROM [{0}]", tableName)
            Else
                selectCommand = String.Format("SELECT {0} FROM [{1}]", define.Item("fields").ToString(), tableName)
            End If

            Dim srcTable As DataTable = _srcDatabase.Executor.ExecuteResultSet(selectCommand, True)
            Dim dstTable As DataTable = _dstDatabase.Executor.ExecuteResultSet(selectCommand, True)

            Dim keys As String = define.Item("key").ToString()
            If Not keys.Equals(String.Empty) Then
                Dim srcPKColumns As New List(Of DataColumn)()
                Dim dstPKColumns As New List(Of DataColumn)()
                For Each key As String In keys.Split(","c)
                    srcPKColumns.Add(srcTable.Columns(key))
                    dstPKColumns.Add(dstTable.Columns(key))
                Next

                srcTable.PrimaryKey = srcPKColumns.ToArray()
                dstTable.PrimaryKey = dstPKColumns.ToArray()
            End If

            Dim srcTableNew As DataTable = srcTable.Clone()
            For Each dr As DataRow In srcTable.Rows
                srcTableNew.Rows.Add(dr.ItemArray)
            Next

            dstTable.Merge(srcTableNew, True)

            '変更行は更新しないので、ここでコミット（Update時にUpdateコマンドを呼び出さないため）
            For Each dr As DataRow In dstTable.Rows
                If dr.RowState = DataRowState.Modified Then dr.AcceptChanges()
            Next

            Dim cmd As SqlClient.SqlCommand = _dstDatabase.CreateCommand(selectCommand)
            Using adapter As New SqlClient.SqlDataAdapter(cmd)
                Using cmdBuilder As New SqlClient.SqlCommandBuilder(adapter)
                    adapter.Update(dstTable)
                End Using
            End Using
        Catch ex As Exception
            Throw
        End Try

    End Sub

#End Region

#Region " GetCustomAdapter "

    'Private Function GetCustomAdapter(ByVal tableName As String, ByVal cmd As SqlClient.SqlCommand, ByVal define As DataRow) As SqlClient.SqlDataAdapter

    '    Try
    '        Dim adapter As New SqlClient.SqlDataAdapter(cmd)
    '        Dim builder As New SqlClient.SqlCommandBuilder(adapter)
    '        Dim fields As String = define.Item("fields").ToString()

    '        Dim paramAry As List(Of String) = New List(Of String)()
    '        For Each field As String In fields.Split(","c)
    '            paramAry.Add("@" & field)
    '        Next

    '        Dim formatArgs As String() = New String() {tableName, fields, String.Join(",", paramAry.ToArray())}
    '        Dim insertCommand As String = String.Format("INSERT INTO [{0}]({1}) VALUES({2})", formatArgs)

    '        adapter.InsertCommand = builder.GetInsertCommand(True)
    '        adapter.InsertCommand.CommandText = insertCommand
    '        adapter.UpdateCommand = builder.GetUpdateCommand(True)
    '        adapter.DeleteCommand = builder.GetDeleteCommand(True)

    '        Return adapter
    '    Catch ex As Exception
    '        Throw
    '    End Try

    'End Function

#End Region

#Region " InvokeProcessReport "

    ''' <summary>
    ''' 進捗レポートイベントを発生させます。
    ''' </summary>
    ''' <param name="counter">オブジェクトの進捗数</param>
    ''' <param name="objectName">オブジェクト名</param>
    ''' <param name="objectType">オブジェクト種別</param>
    ''' <remarks></remarks>
    Private Sub InvokeProcessReport(ByVal counter As Integer, ByVal objectName As String, ByVal objectType As TranferObjectType)
        Dim percent As Integer = CType((counter / _totalObjectCount) * 100, Integer)
        _processReport.Invoke(Me, New ReportArgs(percent, objectName, objectType))
    End Sub

#End Region

#Region " AutoIncrement "

    ''' <summary>
    ''' 指定したテーブルスキーマに自動採番列が含まれるかどうかを取得します。
    ''' </summary>
    ''' <param name="schema">テーブルのスキーマ。</param>
    ''' <returns>自動採番列が含まれる場合は True を返します。</returns>
    ''' <remarks></remarks>
    Private Function AutoIncrement(ByVal schema As DataTable) As Boolean
        For Each col As DataColumn In schema.Columns
            If col.AutoIncrement Then Return True
        Next

        Return False
    End Function

#End Region

#Region " ChaneNameSpame "

    ''' <summary>
    ''' ASPX ファイルに含まれる名前空間を変更します。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ChaneNameSpame()

        Try
            '名前空間を変更する
            _dstDatabase.Executor.ChaneNameSpame()
        Catch ex As Exception
            Throw
        End Try

    End Sub

#End Region

#End Region

#Region " Implement Interface "

#Region " IDisposable "

    Private disposedValue As Boolean = False        ' 重複する呼び出しを検出するには

    ' IDisposable
    Protected Overridable Sub Dispose(ByVal disposing As Boolean)
        If Not Me.disposedValue Then
            If disposing Then
                ' TODO: 他の状態を解放します (マネージ オブジェクト)。
            End If

            ' TODO: ユーザー独自の状態を解放します (アンマネージ オブジェクト)。
            ' TODO: 大きなフィールドを null に設定します。
            Close()
        End If
        Me.disposedValue = True
    End Sub

#Region " IDisposable Support "
    ' このコードは、破棄可能なパターンを正しく実装できるように Visual Basic によって追加されました。
    Public Sub Dispose() Implements IDisposable.Dispose
        ' このコードを変更しないでください。クリーンアップ コードを上の Dispose(ByVal disposing As Boolean) に記述します。
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub
#End Region

#End Region

#End Region

End Class
