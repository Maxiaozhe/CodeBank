﻿Option Compare Binary
Option Explicit On
Option Strict On

Imports System
Imports System.Data
Imports System.IO
Imports System.Text
Imports System.Reflection
Imports System.Diagnostics

''' <summary>
''' ログ出力機能を提供します。
''' </summary>
''' <remarks></remarks>
Public Class LogManager

#Region " Enum "

    ''' <summary>
    ''' ログの種別を表す列挙値を提供します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum LogType As Integer

        ''' <summary>
        ''' [I]情報
        ''' </summary>
        ''' <remarks></remarks>
        Information = 1

        ''' <summary>
        ''' [W]警告
        ''' </summary>
        ''' <remarks></remarks>
        Warning = 2

        ''' <summary>
        ''' [E]例外
        ''' </summary>
        ''' <remarks></remarks>
        Critical = 3

    End Enum

#Region " OperationType "

    ''' <summary>
    ''' オペレーションの種別を表す列挙値を提供します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum OperationType As Integer

        ''' <summary>
        ''' スキップ
        ''' </summary>
        ''' <remarks></remarks>
        Skip

    End Enum

#End Region

#End Region

#Region " Fields "

    ''' <summary>
    ''' 一時的なログのバッファ
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared _logTable As DataTable

#End Region

#Region " Constructor "

    ''' <summary>
    ''' LogManager クラスの新しいインスタンスを初期化します。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub New()

    End Sub

#End Region

#Region " Public Method "

#Region " Initialize "

    ''' <summary>
    ''' このクラスのインスタンスを初期化します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Sub Initialize()

        Try
            _logTable = New DataTable()
            _logTable.Columns.Add(New DataColumn("EventDate", GetType(DateTime)))
            _logTable.Columns.Add(New DataColumn("Type", GetType(LogType)))
            _logTable.Columns.Add(New DataColumn("Message", GetType(String)))
        Catch ex As Exception
            Throw
        End Try

    End Sub

#End Region

#Region " Append "

    ''' <summary>
    ''' テーブルに、指定した例外の内容を追加します。
    ''' </summary>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Public Shared Sub Append(ByVal e As Exception)

        Try
            Dim message As String = e.Message & ControlChars.Tab & e.StackTrace
            Append(DateTime.Now, LogType.Critical, message)
        Catch ex As Exception
            EventLog.WriteEntry(ex.Source, ex.Message, EventLogEntryType.Error)
        End Try

    End Sub

    ''' <summary>
    ''' テーブルにログメッセージを追加します。
    ''' </summary>
    ''' <param name="type">ログの種別</param>
    ''' <param name="messageType">メッセージ種別</param>
    ''' <remarks></remarks>
    Public Shared Sub Append(ByVal type As LogType, ByVal messageType As Informations, ByVal ParamArray formatArgs As String())

        Try
            Dim message As String = My.Resources.Informations.ResourceManager.GetString(messageType.ToString())
            If formatArgs IsNot Nothing AndAlso formatArgs.Length <> 0 Then message = String.Format(message, formatArgs)
            Append(DateTime.Now, type, message)
        Catch ex As Exception
            EventLog.WriteEntry(ex.Source, ex.Message, EventLogEntryType.Error)
        End Try

    End Sub

    ''' <summary>
    ''' テーブルにログメッセージを追加します。
    ''' </summary>
    ''' <param name="objectName"></param>
    ''' <param name="objectType"></param>
    ''' <param name="operation"></param>
    ''' <remarks></remarks>
    Public Shared Sub Append(ByVal objectName As String, ByVal objectType As TranferObjectType, ByVal operation As OperationType)

        Try
            Dim formatArg As String = String.Format("{0}[{1}]", My.Resources.TransferObjectType.ResourceManager.GetString(objectType.ToString()), objectName)
            Dim message As String = String.Empty
            Select Case operation
                Case OperationType.Skip : message = String.Format(My.Resources.Informations.ResourceManager.GetString(Informations.TransferSkipped.ToString()), formatArg)
            End Select

            Append(DateTime.Now, LogType.Information, message)
        Catch ex As Exception
            EventLog.WriteEntry(ex.Source, ex.Message, EventLogEntryType.Error)
        End Try

    End Sub

    ''' <summary>
    ''' テーブルにログメッセージを追加します。
    ''' </summary>
    ''' <param name="objectName">データベースオブジェクト名</param>
    ''' <param name="objectType">オブジェクトの種別</param>
    ''' <param name="result">移行の結果</param>
    ''' <remarks></remarks>
    Public Shared Sub Append(ByVal objectName As String, ByVal objectType As TranferObjectType, ByVal result As Boolean)

        Try
            Dim messageType As Informations
            Dim logType As LogType

            If result Then
                messageType = Informations.TransferSuccess
                logType = LogManager.LogType.Information
            Else
                messageType = Informations.TransferFailed
                logType = LogManager.LogType.Warning
            End If

            Dim formatArg As String = String.Format("{0}[{1}]", My.Resources.TransferObjectType.ResourceManager.GetString(objectType.ToString()), objectName)
            Dim message As String = String.Format(My.Resources.Informations.ResourceManager.GetString(messageType.ToString()), formatArg)
            Append(DateTime.Now, logType, message)
        Catch ex As Exception
            EventLog.WriteEntry(ex.Source, ex.Message, EventLogEntryType.Error)
        End Try

    End Sub

    ''' <summary>
    ''' テーブルにログメッセージを追加します。
    ''' </summary>
    ''' <param name="objectName">データベースオブジェクト名</param>
    ''' <param name="methodType">テーブルの移行モード</param>
    ''' <remarks></remarks>
    Public Shared Sub Append(ByVal objectName As String, ByVal methodType As TransferDefinition.MethodType)

        Try
            Dim formatArg As String = String.Format("{0}[{1}]", My.Resources.TransferObjectType.ResourceManager.GetString(TranferObjectType.Table.ToString()), objectName)
            Dim message As String = String.Format(My.Resources.Informations.ResourceManager.GetString(Informations.TransferSuccess.ToString()), formatArg) & String.Format("(MethodType:{0})", CType(methodType, Integer).ToString())
            Append(DateTime.Now, LogType.Information, message)
        Catch ex As Exception
            EventLog.WriteEntry(ex.Source, ex.Message, EventLogEntryType.Error)
        End Try

    End Sub

    ''' <summary>
    ''' テーブルにログメッセージを追加します。
    ''' </summary>
    ''' <param name="eventDate">ログ出力日</param>
    ''' <param name="type">ログの種別</param>
    ''' <param name="message">メッセージ</param>
    ''' <remarks></remarks>
    Private Shared Sub Append(ByVal eventDate As DateTime, ByVal type As LogType, ByVal message As String)
        Dim row As DataRow = _logTable.NewRow()
        row.Item("EventDate") = eventDate.ToString("yyyy/MM/dd HH:mm:ss")
        row.Item("Type") = Type
        row.Item("Message") = Message
        _logTable.Rows.Add(row)
    End Sub

#End Region

#Region " Write "

    ''' <summary>
    ''' ログテーブルの内容をファイルに出力します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Shared Sub Write()

        Try
            Dim logDir As String = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), My.Settings.logDir)
            If Not Directory.Exists(logDir) Then Directory.CreateDirectory(logDir)

            Dim logFile As String = Path.Combine(logDir, String.Format(My.Settings.logFileName, DateTime.Now.ToString("yyyyMMddHHmmss")))
            Using fs As New FileStream(logFile, FileMode.CreateNew, FileAccess.Write)
                Using sw As New StreamWriter(fs, Encoding.GetEncoding("Shift_JIS"))

                    For Each dr As DataRow In _logTable.Select(String.Empty, "EventDate ASC")
                        Dim lineString As String = DateTime.Parse(dr.Item("EventDate").ToString()).ToString("yyyy/MM/dd HH:mm:ss")
                        Select Case CType(dr.Item("Type"), LogType)
                            Case LogType.Information : lineString &= ControlChars.Tab & "[I]"
                            Case LogType.Warning : lineString &= ControlChars.Tab & "[W]"
                            Case LogType.Critical : lineString &= ControlChars.Tab & "[E]"
                        End Select
                        lineString &= ControlChars.Tab & dr.Item("Message").ToString()

                        sw.WriteLine(lineString)
                    Next

                    sw.Close()

                End Using

                fs.Close()
            End Using

            '最後にテーブルをクリアする
            _logTable.Rows.Clear()
        Catch ex As Exception
            Throw
        End Try

    End Sub

#End Region

#End Region

End Class
