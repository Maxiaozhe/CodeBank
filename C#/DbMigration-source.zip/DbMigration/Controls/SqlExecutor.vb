﻿Option Compare Binary
Option Explicit On
Option Strict On

Imports System
Imports System.Data.SqlClient

''' <summary>
''' SQL Server で Transact-SQL を実行する機能を提供します。
''' </summary>
''' <remarks></remarks>
Public Class SqlExecutor

#Region " Enum "

    ''' <summary>
    ''' IDENTITY_INSERT オプションフラグを提供します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Enum IdentityInsertOptionFlag

        ''' <summary>
        ''' 有効
        ''' </summary>
        ''' <remarks></remarks>
        [On]

        ''' <summary>
        ''' 無効
        ''' </summary>
        ''' <remarks></remarks>
        [Off]

    End Enum

#End Region

#Region " Fields "

    ''' <summary>
    ''' 接続を開いたデータベースオブジェクト
    ''' </summary>
    ''' <remarks></remarks>
    Private _db As SqlDatabase

#End Region

#Region " Constructor "

    ''' <summary>
    ''' SqlExecutor クラスの新しいインスタンスを初期化します。
    ''' </summary>
    ''' <param name="db">データベースオブジェクト</param>
    ''' <remarks></remarks>
    Public Sub New(ByVal db As SqlDatabase)
        _db = db
    End Sub

#End Region

#Region " Public Method "

#Region " SelectDatabases "

    ''' <summary>
    ''' サーバー内のすべてのデータベースを取得します。
    ''' </summary>
    ''' <returns>データベース名のリストを返します。</returns>
    ''' <remarks></remarks>
    Public Function SelectDatabases() As List(Of String)

        Try
            Dim cmd As SqlCommand = _db.CreateCommand(My.Resources.SelectDatabases)
            Dim result As DataTable = ExecuteResultSet(cmd)

            Dim databases As New List(Of String)()
            For Each dr As DataRow In result.Rows
                databases.Add(dr.Item(0).ToString())
            Next

            Return databases
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " SelectSrouceTables "

    ''' <summary>
    ''' データベースにあるテーブルを取得します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SelectSrouceTables() As List(Of String)

        Try
            Dim cmd As SqlCommand = _db.CreateCommand(My.Resources.SelectTables)
            Dim result As DataTable = ExecuteResultSet(cmd)

            Dim tables As New List(Of String)()
            For Each dr As DataRow In result.Rows
                tables.Add(dr.Item(0).ToString())
            Next

            Return tables
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " SelectSourceProcedures "

    ''' <summary>
    ''' データベースにあるストアドプロシージャを取得します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SelectSourceProcedures() As List(Of String)

        Try
            Dim cmd As SqlCommand = _db.CreateCommand(My.Resources.SelectStoredProcedures)
            Dim result As DataTable = ExecuteResultSet(cmd)

            Dim procedures As New List(Of String)()
            For Each dr As DataRow In result.Rows
                procedures.Add(dr.Item(0).ToString())
            Next

            Return procedures
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " SelectSourceFunctions "

    ''' <summary>
    ''' データベースにあるストアドファンクションを取得します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SelectSourceFunctions() As List(Of String)

        Try
            Dim cmd As SqlCommand = _db.CreateCommand(My.Resources.SelectStoredFunctions)
            Dim result As DataTable = ExecuteResultSet(cmd)

            Dim procedures As New List(Of String)()
            For Each dr As DataRow In result.Rows
                procedures.Add(dr.Item(0).ToString())
            Next

            Return procedures
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " SelectViews "

    ''' <summary>
    ''' データベースにあるビューを取得します。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function SelectViews() As List(Of String)

        Try
            Dim cmd As SqlCommand = _db.CreateCommand(My.Resources.SelectViews)
            Dim result As DataTable = ExecuteResultSet(cmd)

            Dim views As New List(Of String)()
            For Each dr As DataRow In result.Rows
                views.Add(dr.Item(0).ToString())
            Next

            Return views
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " SelectColumns "

    ''' <summary>
    ''' 指定したテーブルの列を取得します。
    ''' </summary>
    ''' <param name="tableName">テーブル名</param>
    ''' <returns>カラム情報を格納した DataTable を返します。</returns>
    ''' <remarks></remarks>
    Public Function SelectColumns(ByVal tableName As String) As DataTable

        Try
            Dim commandText As String = String.Format(My.Resources.SelectColumns, tableName)
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            Return ExecuteResultSet(cmd)
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " SelectIndexes "

    ''' <summary>
    ''' 指定したテーブルのすべてのインデックスを取得します。
    ''' </summary>
    ''' <param name="tableName">テーブル名</param>
    ''' <returns>インデックスの情報を格納した DataTable を返します。</returns>
    ''' <remarks></remarks>
    Public Function SelectIndexes(ByVal tableName As String) As DataTable

        Try
            Dim commandText As String = String.Format(My.Resources.SelectIndexes, tableName)
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            Return ExecuteResultSet(cmd)
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " SelectIndexColumns "

    ''' <summary>
    ''' 指定したテーブルの、指定したインデックスに定義されているカラムを取得します。
    ''' </summary>
    ''' <param name="tableName">テーブル名</param>
    ''' <param name="indexId">インデックスID</param>
    ''' <returns>指定したインデックスに定義されているカラムを取得します。</returns>
    ''' <remarks></remarks>
    Public Function SelectIndexColumns(ByVal tableName As String, ByVal indexId As Integer) As DataTable

        Try
            Dim commandText As String = String.Format(My.Resources.SelectIndexColumns, tableName, indexId.ToString())
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            Return ExecuteResultSet(cmd)
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " ExecuteNonQuery "

    ''' <summary>
    ''' 指定したコマンドを実行します。
    ''' </summary>
    ''' <param name="commandText">実行するコマンド</param>
    ''' <returns>指定したコマンドを実行した結果、影響を受けた行数を返します。</returns>
    ''' <remarks></remarks>
    Public Function ExecuteNonQuery(ByVal commandText As String) As Integer
        Return _db.CreateCommand(commandText).ExecuteNonQuery()
    End Function

#End Region

#Region " ExecuteReader "

    ''' <summary>
    ''' 指定したコマンドを実行します。
    ''' </summary>
    ''' <param name="commandText">実行するコマンド</param>
    ''' <returns>結果を読み取るための SqlDataReader オブジェクトを返します。</returns>
    ''' <remarks></remarks>
    Public Function ExecuteReader(ByVal commandText As String) As SqlClient.SqlDataReader
        Return _db.CreateCommand(commandText).ExecuteReader()
    End Function

#End Region

#Region " ExecuteResultSet "

    ''' <summary>
    ''' 指定したコマンドを実行し、結果を DataTable に格納して返します。
    ''' </summary>
    ''' <param name="commandText">実行するコマンド</param>
    ''' <returns>結果を格納した System.Data.DataTable を返します。</returns>
    ''' <remarks></remarks>
    Public Function ExecuteResultSet(ByVal commandText As String) As DataTable
        Return ExecuteResultSet(_db.CreateCommand(commandText))
    End Function

    ''' <summary>
    ''' 指定したコマンドを実行し、結果を DataTable に格納して返します。
    ''' </summary>
    ''' <param name="commandText">実行するコマンド</param>
    ''' <param name="isSchema">スキーマを含めるかどうか</param>
    ''' <returns>結果を格納した System.Data.DataTable を返します。</returns>
    ''' <remarks></remarks>
    Public Function ExecuteResultSet(ByVal commandText As String, ByVal isSchema As Boolean) As DataTable
        Return ExecuteResultSet(_db.CreateCommand(commandText), isSchema)
    End Function

#End Region

#Region " ExistTable "

    ''' <summary>
    ''' 指定したテーブルが、データベースに存在するかどうかを確認します。
    ''' </summary>
    ''' <param name="tableName">テーブル名</param>
    ''' <returns>テーブルが存在する場合は True を、存在しない場合は False を返します。</returns>
    ''' <remarks></remarks>
    Public Function ExistTable(ByVal tableName As String) As Boolean

        Try
            Dim commandText As String = String.Format(My.Resources.ExistTable, tableName)
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            Return Convert.ToBoolean(cmd.ExecuteScalar())
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " RebuildIndex "

    ''' <summary>
    ''' 指定したテーブルのすべてのインデックスを再構築します。
    ''' </summary>
    ''' <param name="tableName">テーブル名</param>
    ''' <remarks></remarks>
    Public Sub RebuildIndex(tableName As String)

        Try
            Dim commandText As String = String.Format(My.Resources.RebuildIndex, tableName)
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Throw
        End Try

    End Sub

#End Region

#Region " ExistProcedure "

    ''' <summary>
    ''' 指定したストアドプロシージャが、データベースに存在するかどうかを確認します。
    ''' </summary>
    ''' <param name="procedureName">ストアドプロシージャ名</param>
    ''' <returns>ストアドプロシージャが存在する場合は True を、存在しない場合は False を返します。</returns>
    ''' <remarks></remarks>
    Public Function ExistProcedure(ByVal procedureName As String) As Boolean

        Try
            Dim commandText As String = String.Format(My.Resources.ExistProcedure, procedureName)
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            Return Convert.ToBoolean(cmd.ExecuteScalar())
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " ExistFunction "

    ''' <summary>
    ''' 指定したストアドファンクションが、データベースに存在するかどうかを確認します。
    ''' </summary>
    ''' <param name="functionName">ストアドファンクション名</param>
    ''' <returns>ストアドファンクションが存在する場合は True を、存在しない場合は False を返します。</returns>
    ''' <remarks></remarks>
    Public Function ExistFunction(ByVal functionName As String) As Boolean

        Try
            Dim commandText As String = String.Format(My.Resources.ExistFunction, functionName)
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            Return Convert.ToBoolean(cmd.ExecuteScalar())
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " ExistView "

    ''' <summary>
    ''' 指定したビューが、データベースに存在するかどうかを確認します。
    ''' </summary>
    ''' <param name="viewName">ビュー名</param>
    ''' <returns>ビューが存在する場合は True を、存在しない場合は False を返します。</returns>
    ''' <remarks></remarks>
    Public Function ExistView(ByVal viewName As String) As Boolean

        Try
            Dim commandText As String = String.Format(My.Resources.ExistView, viewName)
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            Return Convert.ToBoolean(cmd.ExecuteScalar())
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " GetCreateProcedureScript "

    ''' <summary>
    ''' 指定したストアドプロシージャを、移行先のデータベースに作成するためのスクリプトを取得します。
    ''' </summary>
    ''' <param name="procedureName">ストアドプロシージャ名</param>
    ''' <returns>移行先データベースに作成する CREATE スクリプトを返します。</returns>
    ''' <remarks></remarks>
    Public Function GetCreateProcedureScript(ByVal procedureName As String) As String

        Try
            Dim commandText As String = String.Format(My.Resources.CreateProcedure, procedureName)
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            Dim scripts As New System.Text.StringBuilder()
            For Each dr As DataRow In ExecuteResultSet(cmd).Rows
                scripts.Append(dr.Item(0).ToString())
            Next

            Return scripts.ToString()
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " GetCreateFunctionScript "

    ''' <summary>
    ''' 指定したストアドファンクションを、移行先のデータベースに作成するためのスクリプトを取得します。
    ''' </summary>
    ''' <param name="functionName">ストアドファンクション名</param>
    ''' <returns>移行先データベースに作成する CREATE スクリプトを返します。</returns>
    ''' <remarks></remarks>
    Public Function GetCreateFunctionScript(ByVal functionName As String) As String

        Try
            Dim commandText As String = String.Format(My.Resources.CreateFunction, functionName)
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            Dim scripts As New System.Text.StringBuilder()
            For Each dr As DataRow In ExecuteResultSet(cmd).Rows
                scripts.Append(dr.Item(0).ToString())
            Next

            Return scripts.ToString()
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " GetCreateViewScript "

    ''' <summary>
    ''' 指定したビューを、移行先のデータベースに作成するためのスクリプトを取得します。
    ''' </summary>
    ''' <param name="viewName">ビュー名</param>
    ''' <returns>移行先データベースに作成する CREATE スクリプトを返します。</returns>
    ''' <remarks></remarks>
    Public Function GetCreateViewScript(ByVal viewName As String) As String

        Try
            Dim commandText As String = String.Format(My.Resources.CreateView, viewName)
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            Dim scripts As New System.Text.StringBuilder()
            For Each dr As DataRow In ExecuteResultSet(cmd).Rows
                scripts.Append(dr.Item(0).ToString())
            Next

            Return scripts.ToString()
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " TruncateTable "

    ''' <summary>
    ''' 指定したテーブル内のデータを、すべて消去します。
    ''' </summary>
    ''' <param name="tableName">データを消去するテーブル名</param>
    ''' <remarks></remarks>
    Public Sub TruncateTable(ByVal tableName As String)

        Try
            Dim commandText As String = String.Format(My.Resources.TruncateTable, tableName)
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            cmd.ExecuteNonQuery()
        Catch ex As Exception
            Throw
        End Try

    End Sub

#End Region

#Region " GetTableSchema "

    ''' <summary>
    ''' 指定したテーブルのスキーマを取得します。
    ''' </summary>
    ''' <param name="tableName">スキーマを取得するテーブル名。</param>
    ''' <returns>指定したテーブルのスキーマを返します。</returns>
    ''' <remarks></remarks>
    Public Function GetTableSchema(ByVal tableName As String) As DataTable

        Try
            Dim commandText As String = String.Format("SELECT * FROM [{0}]", tableName)
            Dim cmd As SqlCommand = _db.CreateCommand(commandText)

            Dim adapter As New SqlDataAdapter(cmd)
            Dim ds As New DataSet()

            adapter.FillSchema(ds, SchemaType.Source, tableName)

            Return ds.Tables(tableName)
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#Region " SetIdentityInsert "

    ''' <summary>
    ''' 指定したテーブルの IDENTITY_INSERT オプションをセットします。
    ''' </summary>
    ''' <param name="tableName">自動採番列を含むテーブルの名前。</param>
    ''' <param name="optionFlag">セットする IDENTITY_INSERT のフラグ。</param>
    ''' <remarks></remarks>
    Public Sub SetIdentityInsert(ByVal tableName As String, ByVal optionFlag As IdentityInsertOptionFlag)
        Dim flag As String = [Enum].GetName(GetType(IdentityInsertOptionFlag), optionFlag)
        Dim commandText As String = String.Format("SET IDENTITY_INSERT [{0}] {1}", tableName, flag)
        Dim cmd As SqlCommand = _db.CreateCommand(commandText)

        cmd.ExecuteNonQuery()
    End Sub

#End Region

#Region " ChaneNameSpame "

    ''' <summary>
    ''' ポータルとフォームの ASPX ファイルに含まれる名前空間を変更します。
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub ChaneNameSpame()
        Dim cmd As SqlCommand = _db.CreateCommand(My.Resources.ChangeNameSpace)
        cmd.ExecuteNonQuery()
    End Sub

#End Region

#End Region

#Region " Private Method "

#Region " ExecuteResultSet "

    ''' <summary>
    ''' 指定したコマンドを実行し、結果を DataTable に格納して返します。
    ''' </summary>
    ''' <param name="cmd">実行するコマンド</param>
    ''' <returns>結果を格納した System.Data.DataTable を返します。</returns>
    ''' <remarks></remarks>
    Private Function ExecuteResultSet(ByVal cmd As SqlCommand) As DataTable
        Return ExecuteResultSet(cmd, False)
    End Function

    ''' <summary>
    ''' 指定したコマンドを実行し、結果を DataTable に格納して返します。
    ''' </summary>
    ''' <param name="cmd">実行するコマンド</param>
    ''' <param name="isSchema">スキーマを含めるかどうか</param>
    ''' <returns>結果を格納した System.Data.DataTable を返します。</returns>
    ''' <remarks></remarks>
    Private Function ExecuteResultSet(ByVal cmd As SqlCommand, ByVal isSchema As Boolean) As DataTable

        Try
            Dim adapter As New SqlDataAdapter(cmd)
            Dim ds As New DataSet()

            If isSchema Then adapter.FillSchema(ds, SchemaType.Mapped)
            adapter.Fill(ds)

            Return ds.Tables(0)
        Catch ex As Exception
            Throw
        End Try

    End Function

#End Region

#End Region

End Class
