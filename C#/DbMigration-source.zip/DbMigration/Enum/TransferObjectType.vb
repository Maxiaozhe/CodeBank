﻿''' <summary>
''' 移行オブジェクトの種別を表す列挙値を提供します。
''' </summary>
''' <remarks></remarks>
Public Enum TranferObjectType

    ''' <summary>
    ''' テーブル
    ''' </summary>
    ''' <remarks></remarks>
    Table

    ''' <summary>
    ''' ストアドプロシージャ
    ''' </summary>
    ''' <remarks></remarks>
    StoredProcedure

    ''' <summary>
    ''' ストアドファンクション
    ''' </summary>
    ''' <remarks></remarks>
    StoredFunction

    ''' <summary>
    ''' ビュー
    ''' </summary>
    ''' <remarks></remarks>
    View

End Enum

