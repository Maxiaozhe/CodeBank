﻿''' <summary>
''' 警告メッセージを表す列挙値を提供します。
''' </summary>
''' <remarks></remarks>
Public Enum Exclamations

    ''' <summary>
    ''' サーバーが入力されていません。
    ''' </summary>
    ''' <remarks></remarks>
    ServerNotEntry

    ''' <summary>
    ''' ログインが入力されていません。
    ''' </summary>
    ''' <remarks></remarks>
    LoginNotEntry

    ''' <summary>
    ''' データベースが入力されていません。
    ''' </summary>
    ''' <remarks></remarks>
    DatabaseNotEntry

    ''' <summary>
    ''' 処理は完了しましたが、一部移行できなかったオブジェクトがあります。
    ''' ログファイルを参照し、移行に失敗したオブジェクトを確認してください。
    ''' </summary>
    ''' <remarks></remarks>
    PartFailed

End Enum
