﻿''' <summary>
''' 警告メッセージを表す列挙値を提供します。
''' </summary>
''' <remarks></remarks>
Public Enum Errors

    ''' <summary>
    ''' 移行処理に失敗しました。
    ''' ログファイルを参照し、エラーの内容を確認してください。
    ''' </summary>
    ''' <remarks></remarks>
    TransferFailed

End Enum
