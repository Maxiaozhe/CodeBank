﻿''' <summary>
''' 例外メッセージの種別を表す列挙値を提供します。
''' </summary>
''' <remarks></remarks>
Public Enum Exceptions

    ''' <summary>
    ''' 複数の定義が見つかりました。
    ''' </summary>
    ''' <remarks></remarks>
    MultiDefineFound

End Enum
