﻿''' <summary>
''' 確認メッセージを表す列挙値を提供します。
''' </summary>
''' <remarks></remarks>
Public Enum Questions

    ''' <summary>
    ''' データベースの移行を開始しますか？
    ''' </summary>
    ''' <remarks></remarks>
    BeginTransfer

End Enum
