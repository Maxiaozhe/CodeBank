﻿''' <summary>
''' インフォーメーションメッセージを表す列挙値を提供します。
''' </summary>
''' <remarks></remarks>
Public Enum Informations

    ''' <summary>
    ''' 接続のテストに成功しました。
    ''' </summary>
    ''' <remarks></remarks>
    ConnectionSuccess

    ''' <summary>
    ''' データベースの移行を開始しました。
    ''' </summary>
    ''' <remarks></remarks>
    ApplicationStart

    ''' <summary>
    ''' データベースの移行が完了しました。（成功：{0}件 失敗：{1}件）
    ''' </summary>
    ''' <remarks></remarks>
    ApplicationComplete

    ''' <summary>
    ''' データベースの移行に失敗しました。
    ''' </summary>
    ''' <remarks></remarks>
    ApplicationFaield

    ''' <summary>
    ''' データベースの移行が完了しました。
    ''' </summary>
    ''' <remarks></remarks>
    TransferFinished

    ''' <summary>
    ''' {0}の移行が完了しました。
    ''' </summary>
    ''' <remarks></remarks>
    TransferSuccess

    ''' <summary>
    ''' {0}の移行に失敗しました。
    ''' </summary>
    ''' <remarks></remarks>
    TransferFailed

    ''' <summary>
    ''' {0}の移行はスキップしました。
    ''' </summary>
    ''' <remarks></remarks>
    TransferSkipped

    ''' <summary>
    ''' {0}[{1}]を移行しています。
    ''' </summary>
    ''' <remarks></remarks>
    TransferInformation

End Enum
