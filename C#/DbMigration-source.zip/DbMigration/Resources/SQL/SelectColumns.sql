﻿/*
 * <summary>
 * 指定したテーブルの列を取得します。
 * </summary>
 * <param name="{0}">テーブル名</param>
 * <returns>指定したテーブルの列を返します。</returns>
 */
SELECT
	A.[name] As [col_name],
	B.[name] As [type_name],
	prec = ISNULL(A.[prec], 0),
	default_name = ISNULL(C.[name], N''),
	A.[isnullable],
	ISNULL(A.[collation], N'') As collation
FROM
	sys.syscolumns A
	INNER JOIN sys.systypes B ON B.[xusertype] = A.[xusertype]
	LEFT JOIN sys.sysobjects C ON C.[id] = A.[cdefault]
WHERE
	A.[id] = OBJECT_ID(N'{0}')
ORDER BY
	A.[colid]
