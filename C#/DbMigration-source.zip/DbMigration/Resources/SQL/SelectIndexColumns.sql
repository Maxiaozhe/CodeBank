﻿/*
 * <summary>
 * 指定したテーブルのインデックスの列を取得します。
 * </summary>
 * <param name="{0}">テーブル名</param>
 * <param name="{1}">インデックスのID</param>
 * <returns>指定したインデックスIDに該当する、インデックスに指定されている列を返します。</returns>
 */
SELECT
	INDEX_COL(N'{0}', [index_id], [index_column_id]), [is_descending_key] from sys.index_columns
WHERE
	[object_id] = object_id(N'{0}') AND
	[index_id] = {1}
ORDER BY
	[index_column_id]
