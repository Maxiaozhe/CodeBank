﻿/*
 * <summary>
 * 指定したテーブルが、データベースに存在するかどうかを取得します。
 * </summary>
 * <param name="{0}">テーブル名</param>
 * <returns>オブジェクトが存在する場合は 1 を、存在しない場合は 0 を返します。</returns>
 */
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[{0}]') AND type in (N'U'))
	SELECT 1
ELSE
	SELECT 0