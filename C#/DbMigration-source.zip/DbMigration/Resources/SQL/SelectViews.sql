﻿/*
 * <summary>
 * 移行元データベースのビューを全て取得します。
 * </summary>
 */
SELECT [name] FROM sys.views ORDER BY [name]