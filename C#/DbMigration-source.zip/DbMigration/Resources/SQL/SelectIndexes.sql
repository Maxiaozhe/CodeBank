﻿/*
 * <summary>
 * 指定したテーブルのインデックスを取得します。
 * </summary>
 * <param name="{0}">テーブル名</param>
 * <returns>指定したテーブルのすべてのインデックスを返します。</returns>
 */
DECLARE @pk_name sysname

SET @pk_name = (
	SELECT [name] FROM sys.sysobjects
	WHERE
		[xtype] = N'PK' and
		[parent_obj] = OBJECT_ID(N'{0}')
)

--COLUMN[0]:インデックス名
--COLUMN[1]:プライマリキーかどうか
SELECT
	[indid],
	[name],
	(CASE [name] WHEN @pk_name THEN 1 ELSE 0 END)
FROM
	sys.sysindexes
WHERE
	[id] = OBJECT_ID(N'{0}') and
	[indid] > 0 and [indid] < 255 and
	([status] & 64) = 0
