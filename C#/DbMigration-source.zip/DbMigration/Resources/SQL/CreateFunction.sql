﻿/*
 * <summary>
 * 指定したストアドファンクションを作成するためのスクリプトを sys.syscomments から取得します。
 * </summary>
 * <param name="{0}">ストアドファンクション名</param>
 * <returns>sys.syscomments システムビューから CREATE ファンクションの内容を返します。</returns>
 */
SELECT [text] FROM sys.syscomments WHERE [id] = OBJECT_ID(N'{0}') ORDER BY [colid]