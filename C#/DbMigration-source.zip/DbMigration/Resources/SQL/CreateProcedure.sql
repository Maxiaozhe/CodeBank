﻿/*
 * <summary>
 * 指定したストアドプロシージャを作成するためのスクリプトを sys.syscomments から取得します。
 * </summary>
 * <param name="{0}">ストアドプロシージャ名</param>
 * <returns>sys.syscomments システムビューから CREATE プロシージャの内容を返します。</returns>
 */
SELECT [text] FROM sys.syscomments WHERE [id] = OBJECT_ID(N'{0}') ORDER BY [colid]