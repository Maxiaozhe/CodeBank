﻿/*
 * <summary>
 * 指定したテーブル内のデータを、すべて消去します。
 * </summary>
 * <param name="{0}">テーブル名</param>
 * <returns></returns>
 */
TRUNCATE TABLE {0}