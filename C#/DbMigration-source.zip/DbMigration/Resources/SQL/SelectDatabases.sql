﻿/*
 * <summary>
 * SQL Server のデータベースを全て取得します。
 * </summary>
 */
SELECT [name] FROM sys.sysdatabases