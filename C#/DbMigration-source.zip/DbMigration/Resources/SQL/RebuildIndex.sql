﻿/*
 * <summary>
 * 指定したテーブルのすべてのインデックスを再構築します。
 * </summary>
 * <param name="{0}">テーブル名</param>
 * <returns></returns>
 */
ALTER INDEX ALL ON {0}
REBUILD
