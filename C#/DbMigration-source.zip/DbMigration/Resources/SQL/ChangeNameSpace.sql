﻿/*
 * <summary>
 * ポータルとフォームの ASPX ファイルとメニューに含まれる名前空間を変更します。
 * </summary>
 * <returns></returns>
 */
--- ポータルの名前空間を変更
UPDATE PTLF1000 SET STPTLPG = REPLACE(CONVERT(nvarchar(MAX), STPTLPG), N'RTS.RabitFlow', N'RJ.RabitFlow')
--- フォームの名前空間を変更
UPDATE FRMF1000 SET STFRMPG = REPLACE(CONVERT(nvarchar(MAX), STFRMPG), N'RTS.RabitFlow', N'RJ.RabitFlow')
--- メニュー
UPDATE SYSA0010 SET STNMSP = REPLACE(STNMSP, N'RTS.RabitFlow', N'RJ.RabitFlow')
--- 拡張メニュー
UPDATE MNUA0001 SET STCLASS = REPLACE(STCLASS, N'RTS.RabitFlow', N'RJ.RabitFlow')
