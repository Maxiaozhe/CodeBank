﻿/*
 * <summary>
 * 指定したストアドファンクションが、データベースに存在するかどうかを取得します。
 * </summary>
 * <param name="{0}">ストアドファンクション名</param>
 * <returns>オブジェクトが存在する場合は 1 を、存在しない場合は 0 を返します。</returns>
 */
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[{0}]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
	SELECT 1
ELSE
	SELECT 0
