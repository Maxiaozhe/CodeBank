﻿/*
 * <summary>
 * 移行元データベースのテーブルを全て取得します。
 * </summary>
 */
SELECT
	[name]
FROM
	sys.sysobjects
WHERE
	[type] = N'U' AND
	OBJECTPROPERTY([id], N'IsMSShipped') = 0 AND
	[id] NOT IN (
		SELECT [major_id] FROM sys.extended_properties
		WHERE
			[minor_id] = 0 AND [class] = 1 AND [name] = N'microsoft_database_tools_support'
	)
ORDER BY
	[name]
